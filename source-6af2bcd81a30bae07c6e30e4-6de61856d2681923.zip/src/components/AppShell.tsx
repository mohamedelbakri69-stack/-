import { Link } from '@tanstack/react-router'
import {
  BookOpenText,
  CalendarRange,
  LayoutDashboard,
  ListChecks,
  Users,
} from 'lucide-react'
import type { ReactNode } from 'react'
import { isStruggling, summaries, taskState } from '../lib/analytics'
import { SCHOOL_NAME, SCHOOL_YEAR, TEACHER_NAME } from '../lib/fixtures'
import { useStore } from '../lib/store'

const strugglingCount = summaries.filter(isStruggling).length

export function AppShell({ children }: { children: ReactNode }) {
  const { tasks } = useStore()
  const overdue = tasks.filter((t) => taskState(t).state === 'متأخرة').length

  const nav = [
    { to: '/', label: 'لوحة القيادة', icon: LayoutDashboard, badge: null },
    { to: '/students', label: 'التلاميذ', icon: Users, badge: strugglingCount, tone: 'clay' },
    { to: '/tasks', label: 'المهام', icon: ListChecks, badge: overdue || null, tone: 'bad' },
    { to: '/curriculum', label: 'التوزيع السنوي', icon: CalendarRange, badge: null },
  ] as const

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[17rem_1fr]">
      <aside className="no-print zellige relative bg-teal-deep text-paper lg:sticky lg:top-0 lg:h-screen lg:flex lg:flex-col">
        <div className="flex items-center gap-3 px-5 py-4 lg:px-7 lg:pt-8 lg:pb-6">
          <span className="grid size-11 place-items-center rounded-xl bg-saffron/90 text-teal-deep shadow-inner">
            <BookOpenText className="size-6" strokeWidth={1.8} />
          </span>
          <div>
            <p className="font-serif text-3xl leading-none font-bold">مِداد</p>
            <p className="mt-1 text-xs text-paper/60">لوحة أستاذ اللغة العربية</p>
          </div>
        </div>

        <nav
          aria-label="التنقل الرئيسي"
          className="flex gap-1 overflow-x-auto px-3 pb-3 lg:flex-col lg:px-4 lg:pb-0"
        >
          {nav.map(({ to, label, icon: Icon, badge, ...rest }) => (
            <Link
              key={to}
              to={to}
              activeOptions={{ exact: to === '/' }}
              className="group flex shrink-0 items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm text-paper/75 transition hover:bg-white/8 hover:text-paper data-[status=active]:bg-paper data-[status=active]:font-semibold data-[status=active]:text-teal-deep"
            >
              <Icon className="size-[1.15rem]" strokeWidth={1.8} />
              <span>{label}</span>
              {badge ? (
                <span
                  className={`ms-auto rounded-full px-2 py-0.5 text-[0.7rem] font-semibold text-white num ${
                    'tone' in rest && rest.tone === 'bad' ? 'bg-bad' : 'bg-clay'
                  }`}
                >
                  {badge}
                </span>
              ) : null}
            </Link>
          ))}
        </nav>

        <div className="mt-auto hidden px-7 pb-8 lg:block">
          <div className="rounded-xl border border-white/10 bg-white/5 p-4">
            <p className="font-serif text-lg leading-snug text-paper/90">
              «العلمُ صيدٌ والكتابةُ قيدُه»
            </p>
            <div className="mt-4 border-t border-white/10 pt-3 text-xs leading-6 text-paper/60">
              <p className="text-paper/85">{TEACHER_NAME}</p>
              <p>{SCHOOL_NAME}</p>
              <p>
                الموسم الدراسي <span className="num">{SCHOOL_YEAR}</span>
              </p>
            </div>
          </div>
        </div>
      </aside>

      <main className="min-w-0 px-4 py-6 sm:px-6 lg:px-10 lg:py-9">{children}</main>
    </div>
  )
}
