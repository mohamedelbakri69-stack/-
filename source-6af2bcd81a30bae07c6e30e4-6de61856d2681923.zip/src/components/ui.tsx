import type { LucideIcon } from 'lucide-react'
import type { ReactNode } from 'react'
import { formatScore } from '../lib/analytics'

export function PageHeader({
  eyebrow,
  title,
  children,
  actions,
}: {
  eyebrow?: string
  title: string
  children?: ReactNode
  actions?: ReactNode
}) {
  return (
    <header className="rise mb-7 flex flex-wrap items-end justify-between gap-4">
      <div>
        {eyebrow ? (
          <p className="mb-1.5 text-sm font-medium tracking-wide text-clay">{eyebrow}</p>
        ) : null}
        <h1 className="text-3xl text-ink sm:text-[2.35rem] sm:leading-tight">{title}</h1>
        {children ? <div className="mt-2 max-w-2xl text-ink-soft">{children}</div> : null}
      </div>
      {actions ? <div className="no-print flex flex-wrap gap-2">{actions}</div> : null}
    </header>
  )
}

export function StatTile({
  label,
  value,
  hint,
  icon: Icon,
  tone = 'teal',
  delay = 0,
}: {
  label: string
  value: ReactNode
  hint?: ReactNode
  icon: LucideIcon
  tone?: 'teal' | 'clay' | 'saffron' | 'bad' | 'good'
  delay?: number
}) {
  const tones = {
    teal: 'bg-teal-soft text-teal',
    clay: 'bg-clay-soft text-clay',
    saffron: 'bg-saffron-soft text-[#8a6a14]',
    bad: 'bg-bad-soft text-bad',
    good: 'bg-good-soft text-good',
  }
  return (
    <div className="card rise p-5" style={{ animationDelay: `${delay}ms` }}>
      <div className="flex items-start justify-between gap-3">
        <p className="text-sm text-ink-soft">{label}</p>
        <span className={`grid size-9 place-items-center rounded-lg ${tones[tone]}`}>
          <Icon className="size-[1.1rem]" strokeWidth={1.9} />
        </span>
      </div>
      <p className="mt-2 font-display text-[2.1rem] leading-none text-ink">{value}</p>
      {hint ? <p className="mt-2.5 text-xs leading-5 text-ink-faint">{hint}</p> : null}
    </div>
  )
}

export function Progress({
  value,
  marker,
  color = 'var(--color-teal)',
  label,
}: {
  value: number
  marker?: number
  color?: string
  label: string
}) {
  return (
    <div
      role="progressbar"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(value * 100)}
      className="relative h-2 w-full overflow-hidden rounded-full bg-paper-2"
    >
      <div
        className="absolute inset-y-0 start-0 rounded-full transition-[width] duration-500"
        style={{ width: `${Math.min(100, value * 100)}%`, background: color }}
      />
      {marker !== undefined ? (
        <div
          title="المستوى المتوقع حسب التوزيع السنوي"
          className="absolute inset-y-[-2px] w-0.5 bg-ink/60"
          style={{ insetInlineStart: `${Math.min(100, marker * 100)}%` }}
        />
      ) : null}
    </div>
  )
}

export function Pill({
  children,
  tone = 'neutral',
}: {
  children: ReactNode
  tone?: 'neutral' | 'good' | 'bad' | 'warn' | 'teal'
}) {
  const tones = {
    neutral: 'bg-paper-2 text-ink-soft',
    good: 'bg-good-soft text-good',
    bad: 'bg-bad-soft text-bad',
    warn: 'bg-saffron-soft text-[#7d5f10]',
    teal: 'bg-teal-soft text-teal',
  }
  return (
    <span
      className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium ${tones[tone]}`}
    >
      {children}
    </span>
  )
}

export function ScoreBadge({ score }: { score: number | null }) {
  const tone =
    score === null
      ? 'text-ink-faint'
      : score < 10
        ? 'text-bad'
        : score >= 14
          ? 'text-good'
          : 'text-ink'
  return <span className={`num font-semibold ${tone}`}>{formatScore(score)}</span>
}

export function SectionTitle({
  children,
  aside,
}: {
  children: ReactNode
  aside?: ReactNode
}) {
  return (
    <div className="mb-4 flex items-center justify-between gap-3">
      <h2 className="text-xl text-ink">{children}</h2>
      {aside}
    </div>
  )
}

export function Avatar({ name, color }: { name: string; color: string }) {
  return (
    <span
      aria-hidden
      className="grid size-9 shrink-0 place-items-center rounded-full font-display text-sm text-white"
      style={{ background: color }}
    >
      {name.trim().charAt(0)}
    </span>
  )
}
