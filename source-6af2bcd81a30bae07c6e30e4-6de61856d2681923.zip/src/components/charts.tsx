import {
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Filler,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
  Legend,
} from 'chart.js'
import { useEffect, useState, type ReactNode } from 'react'
import { Bar, Line } from 'react-chartjs-2'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Tooltip,
  Legend,
  Filler,
)
ChartJS.defaults.font.family = "'IBM Plex Sans Arabic', sans-serif"
ChartJS.defaults.color = '#55625f'
ChartJS.defaults.borderColor = 'rgba(29, 43, 42, 0.08)'

const rtlTooltip = {
  rtl: true,
  textDirection: 'rtl' as const,
  backgroundColor: '#142f2d',
  padding: 10,
  cornerRadius: 8,
  titleFont: { weight: 600 as const },
}

/** Chart.js draws on canvas, so charts only mount in the browser. */
function ClientOnly({ children, height }: { children: ReactNode; height: number }) {
  const [ready, setReady] = useState(false)
  useEffect(() => setReady(true), [])
  return (
    <div className="relative w-full" style={{ height }}>
      {ready ? (
        children
      ) : (
        <div className="h-full w-full animate-pulse rounded-xl bg-paper-2/70 motion-reduce:animate-none" />
      )}
    </div>
  )
}

const comma = (n: number) => n.toFixed(2).replace('.', ',')

export function ClassAveragesChart({
  rows,
}: {
  rows: { label: string; value: number; color: string }[]
}) {
  return (
    <ClientOnly height={240}>
      <Bar
        role="img"
        aria-label={`معدلات الأقسام: ${rows.map((r) => `${r.label} ${comma(r.value)}`).join('، ')}`}
        data={{
          labels: rows.map((r) => r.label),
          datasets: [
            {
              label: 'المعدل',
              data: rows.map((r) => r.value),
              backgroundColor: rows.map((r) => r.color),
              borderRadius: 6,
              maxBarThickness: 46,
            },
          ],
        }}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: { ...rtlTooltip, callbacks: { label: (c) => ` المعدل: ${comma(c.parsed.y ?? 0)} / 20` } },
          },
          scales: {
            x: { reverse: true, grid: { display: false } },
            y: { position: 'right', min: 0, max: 20, ticks: { stepSize: 5 } },
          },
        }}
      />
    </ClientOnly>
  )
}

export function DistributionChart({
  rows,
}: {
  rows: { label: string; count: number; max: number }[]
}) {
  return (
    <ClientOnly height={240}>
      <Bar
        role="img"
        aria-label={`توزيع المعدلات: ${rows.map((r) => `${r.label}: ${r.count}`).join('، ')}`}
        data={{
          labels: rows.map((r) => r.label),
          datasets: [
            {
              label: 'عدد التلاميذ',
              data: rows.map((r) => r.count),
              backgroundColor: rows.map((r) => (r.max <= 10 ? '#b5562b' : '#1f5f5b')),
              borderRadius: 5,
              maxBarThickness: 40,
            },
          ],
        }}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: { ...rtlTooltip, callbacks: { label: (c) => ` ${c.parsed.y} تلميذاً` } },
          },
          scales: {
            x: { reverse: true, grid: { display: false } },
            y: { position: 'right', beginAtZero: true, ticks: { precision: 0 } },
          },
        }}
      />
    </ClientOnly>
  )
}

export function AttendanceChart({ rows }: { rows: { label: string; rate: number }[] }) {
  return (
    <ClientOnly height={200}>
      <Line
        role="img"
        aria-label={`نسبة الحضور الأسبوعية: ${rows.map((r) => `${r.label} ${Math.round(r.rate * 100)}٪`).join('، ')}`}
        data={{
          labels: rows.map((r) => r.label),
          datasets: [
            {
              label: 'نسبة الحضور',
              data: rows.map((r) => Math.round(r.rate * 1000) / 10),
              borderColor: '#1f5f5b',
              backgroundColor: 'rgba(31, 95, 91, 0.12)',
              fill: true,
              tension: 0.35,
              pointRadius: 3,
              pointBackgroundColor: '#1f5f5b',
            },
          ],
        }}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: { ...rtlTooltip, callbacks: { label: (c) => ` الحضور: ${c.parsed.y}٪` } },
          },
          scales: {
            x: { reverse: true, grid: { display: false } },
            y: { position: 'right', min: 80, max: 100, ticks: { callback: (v) => `${v}٪` } },
          },
        }}
      />
    </ClientOnly>
  )
}

export function StudentGradesChart({
  rows,
}: {
  rows: { label: string; score: number; classAverage: number }[]
}) {
  return (
    <ClientOnly height={220}>
      <Line
        role="img"
        aria-label={`تطور نقط التلميذ: ${rows.map((r) => `${r.label} ${comma(r.score)}`).join('، ')}`}
        data={{
          labels: rows.map((r) => r.label),
          datasets: [
            {
              label: 'نقطة التلميذ',
              data: rows.map((r) => r.score),
              borderColor: '#b5562b',
              backgroundColor: '#b5562b',
              pointRadius: 5,
              tension: 0.25,
            },
            {
              label: 'معدل القسم',
              data: rows.map((r) => Math.round(r.classAverage * 100) / 100),
              borderColor: '#8a918c',
              backgroundColor: '#8a918c',
              borderDash: [5, 5],
              pointRadius: 3,
              tension: 0.25,
            },
          ],
        }}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'bottom', rtl: true, labels: { boxWidth: 12, usePointStyle: true } },
            tooltip: {
              ...rtlTooltip,
              callbacks: { label: (c) => ` ${c.dataset.label}: ${comma(c.parsed.y ?? 0)}` },
            },
          },
          scales: {
            x: { reverse: true, grid: { display: false } },
            y: { position: 'right', min: 0, max: 20, ticks: { stepSize: 5 } },
          },
        }}
      />
    </ClientOnly>
  )
}
