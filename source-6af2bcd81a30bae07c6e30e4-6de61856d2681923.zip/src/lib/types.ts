export type Level = 'tc' | '1bac' | '2bac'

export interface ClassGroup {
  id: string
  code: string
  name: string
  level: Level
  size: number
  room: string
  /** Days of the week with an Arabic session (0 = Sunday). */
  weekdays: number[]
  color: string
}

export interface Assessment {
  id: string
  classId: string
  title: string
  type: 'تقويم' | 'فرض' | 'أنشطة'
  date: string
}

export interface Homework {
  id: string
  classId: string
  title: string
  assigned: string
  due: string
}

export type HomeworkStatus = 'منجز' | 'متأخر' | 'غير منجز'

export interface AttendanceEvent {
  date: string
  status: 'غائب' | 'متأخر'
  justified: boolean
}

export interface BehaviorNote {
  date: string
  kind: 'إيجابي' | 'سلبي'
  note: string
}

export interface Student {
  id: string
  massar: string
  firstName: string
  lastName: string
  gender: 'ذ' | 'أ'
  classId: string
  seat: number
  birthDate: string
  guardianPhone: string
  grades: { assessmentId: string; score: number }[]
  /** Only absences and late arrivals are stored; every other session is "present". */
  attendance: AttendanceEvent[]
  homework: { homeworkId: string; status: HomeworkStatus }[]
  behavior: BehaviorNote[]
  /** Monthly participation rating out of 10. */
  participation: { month: string; score: number }[]
}

export interface Lesson {
  id: string
  classId: string
  order: number
  unit: string
  title: string
  component: 'نصوص' | 'علوم اللغة' | 'تعبير وإنشاء' | 'تقويم'
  plannedDate: string
  doneDate: string | null
}

export type TaskCategory =
  | 'تحضير الدروس'
  | 'التصحيح'
  | 'الفروض والتقويم'
  | 'الدعم والمعالجة'
  | 'إداري'
  | 'التواصل'

export interface Task {
  id: string
  title: string
  category: TaskCategory
  classId: string | null
  due: string
  recurrence: 'أسبوعية' | null
  done: boolean
  notes: string | null
}
