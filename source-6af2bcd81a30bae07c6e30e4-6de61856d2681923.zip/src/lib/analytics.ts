import {
  assessments,
  classes,
  homework,
  REFERENCE_DATE,
  sessionDates,
  students,
} from './fixtures'
import type { ClassGroup, Lesson, Student, Task } from './types'

// ---------------------------------------------------------------- التنسيق
const monthNames = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'ماي', 'يونيو',
  'يوليوز', 'غشت', 'شتنبر', 'أكتوبر', 'نونبر', 'دجنبر',
]
const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']

const toDate = (iso: string) => new Date(`${iso}T12:00:00Z`)

export function formatDate(iso: string, withDay = false) {
  const d = toDate(iso)
  const base = `${d.getUTCDate()} ${monthNames[d.getUTCMonth()]}`
  return withDay ? `${dayNames[d.getUTCDay()]} ${base}` : base
}
export function formatLongDate(iso: string) {
  const d = toDate(iso)
  return `${dayNames[d.getUTCDay()]} ${d.getUTCDate()} ${monthNames[d.getUTCMonth()]} ${d.getUTCFullYear()}`
}
export const formatMonth = (yyyyMm: string) =>
  monthNames[Number(yyyyMm.slice(5, 7)) - 1]

/** Moroccan school convention: two decimals with a comma (12,50). */
export const formatScore = (n: number | null) =>
  n === null ? '—' : n.toFixed(2).replace('.', ',')
export const formatPercent = (n: number) =>
  `${(Math.round(n * 1000) / 10).toString().replace('.', ',')}٪`

export const daysBetween = (from: string, to: string) =>
  Math.round((toDate(to).getTime() - toDate(from).getTime()) / 86_400_000)

export const today = () => REFERENCE_DATE

// ---------------------------------------------------------------- الأقسام
const classMap = new Map(classes.map((c) => [c.id, c]))
export const getClass = (id: string) => classMap.get(id) as ClassGroup
const sessionsByClass = new Map(classes.map((c) => [c.id, sessionDates(c)]))
export const getSessions = (classId: string) => sessionsByClass.get(classId) ?? []

// ---------------------------------------------------------------- التعثر
/** Thresholds for the struggling-student alert. Every rule is shown to the teacher. */
export const RISK_RULES = {
  average: 10,
  unjustifiedAbsences: 3,
  missingHomework: 2,
  negativeBehavior: 2,
  gradeDrop: 3,
  participation: 4,
} as const

export interface RiskReason {
  key: 'average' | 'absence' | 'homework' | 'behavior' | 'drop' | 'participation'
  label: string
}

export interface StudentSummary {
  student: Student
  group: ClassGroup
  fullName: string
  average: number | null
  latest: number | null
  trend: number | null
  sessions: number
  absences: number
  unjustified: number
  lates: number
  attendanceRate: number
  homeworkDone: number
  homeworkTotal: number
  homeworkMissing: number
  negative: number
  positive: number
  participation: number
  reasons: RiskReason[]
}

const mean = (list: number[]) =>
  list.length ? list.reduce((a, b) => a + b, 0) / list.length : null

export function summarize(student: Student): StudentSummary {
  const group = getClass(student.classId)
  const scores = student.grades.map((g) => g.score)
  const average = mean(scores)
  const exams = student.grades.filter(
    (g) => assessmentMap.get(g.assessmentId)?.type !== 'أنشطة',
  )
  const trend =
    exams.length >= 2 ? exams[exams.length - 1].score - exams[0].score : null
  const sessions = getSessions(student.classId).length
  const absences = student.attendance.filter((a) => a.status === 'غائب')
  const unjustified = absences.filter((a) => !a.justified).length
  const lates = student.attendance.filter((a) => a.status === 'متأخر').length
  const homeworkDone = student.homework.filter((h) => h.status === 'منجز').length
  const homeworkMissing = student.homework.filter((h) => h.status === 'غير منجز').length
  const negative = student.behavior.filter((b) => b.kind === 'سلبي').length
  const positive = student.behavior.length - negative
  const participation = mean(student.participation.map((p) => p.score)) ?? 0

  const reasons: RiskReason[] = []
  if (average !== null && average < RISK_RULES.average)
    reasons.push({ key: 'average', label: `معدل ${formatScore(average)}` })
  if (unjustified >= RISK_RULES.unjustifiedAbsences)
    reasons.push({ key: 'absence', label: `${unjustified} غيابات غير مبررة` })
  if (homeworkMissing >= RISK_RULES.missingHomework)
    reasons.push({ key: 'homework', label: `${homeworkMissing} واجبات غير منجزة` })
  if (negative >= RISK_RULES.negativeBehavior)
    reasons.push({ key: 'behavior', label: `${negative} ملاحظات سلوكية` })
  if (trend !== null && trend <= -RISK_RULES.gradeDrop)
    reasons.push({ key: 'drop', label: `تراجع ${formatScore(Math.abs(trend))} نقطة` })
  if (participation < RISK_RULES.participation)
    reasons.push({ key: 'participation', label: 'مشاركة ضعيفة' })

  return {
    student,
    group,
    fullName: `${student.firstName} ${student.lastName}`,
    average,
    latest: scores.at(-1) ?? null,
    trend,
    sessions,
    absences: absences.length,
    unjustified,
    lates,
    attendanceRate: sessions ? 1 - absences.length / sessions : 1,
    homeworkDone,
    homeworkTotal: student.homework.length,
    homeworkMissing,
    negative,
    positive,
    participation,
    reasons,
  }
}

const assessmentMap = new Map(assessments.map((a) => [a.id, a]))
export const getAssessment = (id: string) => assessmentMap.get(id)!
const homeworkMap = new Map(homework.map((h) => [h.id, h]))
export const getHomework = (id: string) => homeworkMap.get(id)!

export const summaries: StudentSummary[] = students.map(summarize)
const summaryMap = new Map(summaries.map((s) => [s.student.id, s]))
export const getSummary = (id: string) => summaryMap.get(id)

/** A student is flagged as struggling when at least two rules fire, or the average is below 10. */
export const isStruggling = (s: StudentSummary) =>
  s.reasons.length >= 2 || s.reasons.some((r) => r.key === 'average')

// ---------------------------------------------------------------- إحصائيات الأقسام
export interface ClassStats {
  group: ClassGroup
  count: number
  average: number
  passRate: number
  attendanceRate: number
  homeworkRate: number
  struggling: number
  best: StudentSummary
}

export function classStats(group: ClassGroup): ClassStats {
  const list = summaries.filter((s) => s.group.id === group.id)
  const avgs = list.map((s) => s.average ?? 0)
  return {
    group,
    count: list.length,
    average: mean(avgs) ?? 0,
    passRate: avgs.filter((a) => a >= 10).length / list.length,
    attendanceRate: mean(list.map((s) => s.attendanceRate)) ?? 1,
    homeworkRate:
      list.reduce((a, s) => a + s.homeworkDone, 0) /
      list.reduce((a, s) => a + s.homeworkTotal, 0),
    struggling: list.filter(isStruggling).length,
    best: list.reduce((a, b) => ((b.average ?? 0) > (a.average ?? 0) ? b : a)),
  }
}
export const allClassStats = classes.map(classStats)

export const GRADE_BANDS = [
  { label: 'أقل من 5', min: 0, max: 5 },
  { label: '5 – 8', min: 5, max: 8 },
  { label: '8 – 10', min: 8, max: 10 },
  { label: '10 – 12', min: 10, max: 12 },
  { label: '12 – 14', min: 12, max: 14 },
  { label: '14 – 16', min: 14, max: 16 },
  { label: '16 فما فوق', min: 16, max: 21 },
]
export function gradeDistribution(list: StudentSummary[]) {
  return GRADE_BANDS.map((band) => ({
    ...band,
    count: list.filter(
      (s) => s.average !== null && s.average >= band.min && s.average < band.max,
    ).length,
  }))
}

/** Weekly attendance rate across the selected classes. */
export function weeklyAttendance(classIds: string[]) {
  const weeks = new Map<string, { held: number; absent: number }>()
  for (const id of classIds) {
    const group = getClass(id)
    const classStudents = summaries.filter((s) => s.group.id === id)
    for (const date of getSessions(id)) {
      const d = toDate(date)
      const monday = new Date(d)
      monday.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7))
      const key = monday.toISOString().slice(0, 10)
      const bucket = weeks.get(key) ?? { held: 0, absent: 0 }
      bucket.held += group.size
      bucket.absent += classStudents.filter((s) =>
        s.student.attendance.some((a) => a.date === date && a.status === 'غائب'),
      ).length
      weeks.set(key, bucket)
    }
  }
  return [...weeks.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([week, v]) => ({ week, rate: 1 - v.absent / v.held }))
}

// ---------------------------------------------------------------- التوزيع السنوي
export function lessonProgress(classId: string, list: Lesson[]) {
  const own = list.filter((l) => l.classId === classId)
  const done = own.filter((l) => l.doneDate).length
  const expected = own.filter((l) => l.plannedDate <= REFERENCE_DATE).length
  return {
    total: own.length,
    done,
    expected,
    behind: Math.max(0, expected - done),
    ahead: Math.max(0, done - expected),
    percent: own.length ? done / own.length : 0,
    next: own.find((l) => !l.doneDate) ?? null,
  }
}

// ---------------------------------------------------------------- المهام
export type TaskState = 'منجزة' | 'متأخرة' | 'اليوم' | 'هذا الأسبوع' | 'لاحقاً'

export function taskState(task: Task): { state: TaskState; days: number } {
  const days = daysBetween(REFERENCE_DATE, task.due)
  if (task.done) return { state: 'منجزة', days }
  if (days < 0) return { state: 'متأخرة', days }
  if (days === 0) return { state: 'اليوم', days }
  if (days <= 7) return { state: 'هذا الأسبوع', days }
  return { state: 'لاحقاً', days }
}

export function dueLabel(task: Task) {
  const { state, days } = taskState(task)
  if (state === 'متأخرة') return days === -1 ? 'متأخرة بيوم واحد' : `متأخرة بـ ${-days} أيام`
  if (state === 'اليوم') return 'مستحقة اليوم'
  if (state === 'منجزة') return 'أُنجزت'
  return days === 1 ? 'غداً' : `بعد ${days} أيام`
}

export const nextWeek = (iso: string) => {
  const d = toDate(iso)
  d.setUTCDate(d.getUTCDate() + 7)
  return d.toISOString().slice(0, 10)
}

// ---------------------------------------------------------------- الملف الشخصي
export interface TimelineEvent {
  date: string
  kind: 'نقطة' | 'غياب' | 'تأخر' | 'سلوك إيجابي' | 'سلوك سلبي' | 'واجب'
  title: string
  detail: string
  tone: 'good' | 'bad' | 'neutral'
}

export function timeline(student: Student): TimelineEvent[] {
  const events: TimelineEvent[] = []
  for (const g of student.grades) {
    const a = getAssessment(g.assessmentId)
    events.push({
      date: a.date,
      kind: 'نقطة',
      title: a.title,
      detail: `${formatScore(g.score)} / 20`,
      tone: g.score >= 10 ? 'good' : 'bad',
    })
  }
  for (const a of student.attendance)
    events.push({
      date: a.date,
      kind: a.status === 'غائب' ? 'غياب' : 'تأخر',
      title: a.status === 'غائب' ? 'غياب عن الحصة' : 'تأخر عن الحصة',
      detail: a.status === 'غائب' ? (a.justified ? 'مبرر' : 'غير مبرر') : 'تأخر',
      tone: a.justified ? 'neutral' : 'bad',
    })
  for (const b of student.behavior)
    events.push({
      date: b.date,
      kind: b.kind === 'إيجابي' ? 'سلوك إيجابي' : 'سلوك سلبي',
      title: b.note,
      detail: b.kind,
      tone: b.kind === 'إيجابي' ? 'good' : 'bad',
    })
  for (const h of student.homework) {
    const hw = getHomework(h.homeworkId)
    if (hw.due > REFERENCE_DATE) continue
    events.push({
      date: hw.due,
      kind: 'واجب',
      title: hw.title,
      detail: h.status,
      tone: h.status === 'منجز' ? 'good' : h.status === 'متأخر' ? 'neutral' : 'bad',
    })
  }
  return events.sort((a, b) => b.date.localeCompare(a.date))
}

/** Builds a UTF-8 CSV (with BOM so Excel shows Arabic correctly). */
export function studentCsv(s: StudentSummary) {
  const rows: string[][] = [
    ['الملف الشخصي للتلميذ', s.fullName],
    ['رقم مسار', s.student.massar],
    ['القسم', s.group.name],
    ['المعدل الحالي', formatScore(s.average)],
    ['نسبة الحضور', formatPercent(s.attendanceRate)],
    ['الغيابات (غير المبررة)', `${s.absences} (${s.unjustified})`],
    ['الواجبات المنجزة', `${s.homeworkDone} / ${s.homeworkTotal}`],
    ['تقدير المشاركة', `${formatScore(s.participation)} / 10`],
    ['مؤشرات التعثر', s.reasons.map((r) => r.label).join('، ') || 'لا شيء'],
    [],
    ['التاريخ', 'النوع', 'البيان', 'التفاصيل'],
    ...timeline(s.student).map((e) => [e.date, e.kind, e.title, e.detail]),
  ]
  const csv = rows
    .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(','))
    .join('\r\n')
  return `﻿${csv}`
}
