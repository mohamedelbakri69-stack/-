import { createContext, useContext, useMemo, useState, type ReactNode } from 'react'
import { lessons as lessonFixtures, REFERENCE_DATE, tasks as taskFixtures } from './fixtures'
import { nextWeek } from './analytics'
import type { Lesson, Task } from './types'

/**
 * Session-level store for the interactive parts of milestone 1 (tasks and
 * lesson progress). It starts from the fixtures and keeps changes while the
 * teacher navigates. Milestone 2 replaces these setters with server functions
 * backed by Netlify Database.
 */
interface Store {
  tasks: Task[]
  lessons: Lesson[]
  toggleTask: (id: string) => void
  addTask: (task: Omit<Task, 'id' | 'done'>) => void
  removeTask: (id: string) => void
  toggleLesson: (id: string) => void
}

const StoreContext = createContext<Store | null>(null)

export function StoreProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState(taskFixtures)
  const [lessons, setLessons] = useState(lessonFixtures)

  const value = useMemo<Store>(
    () => ({
      tasks,
      lessons,
      toggleTask: (id) =>
        setTasks((list) => {
          const task = list.find((t) => t.id === id)
          if (!task) return list
          const updated = list.map((t) => (t.id === id ? { ...t, done: !t.done } : t))
          // Completing a recurring task schedules its next occurrence.
          if (!task.done && task.recurrence) {
            const nextId = `${task.id}~${nextWeek(task.due)}`
            if (!list.some((t) => t.id === nextId))
              updated.push({ ...task, id: nextId, due: nextWeek(task.due), done: false })
          }
          return updated
        }),
      addTask: (task) =>
        setTasks((list) => [
          ...list,
          { ...task, id: `t-${list.length + 1}-${task.due}`, done: false },
        ]),
      removeTask: (id) => setTasks((list) => list.filter((t) => t.id !== id)),
      toggleLesson: (id) =>
        setLessons((list) =>
          list.map((l) =>
            l.id === id ? { ...l, doneDate: l.doneDate ? null : REFERENCE_DATE } : l,
          ),
        ),
    }),
    [tasks, lessons],
  )

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export function useStore() {
  const store = useContext(StoreContext)
  if (!store) throw new Error('useStore must be used inside <StoreProvider>')
  return store
}
