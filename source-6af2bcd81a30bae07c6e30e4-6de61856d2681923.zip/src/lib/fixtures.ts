/**
 * بيانات تجريبية (Fixtures)
 * ------------------------------------------------------------------
 * All sample data for milestone 1 lives in this single module so a later
 * milestone can swap it for Netlify Database queries without touching the
 * screens. Data is generated with a seeded PRNG, so server render and
 * client hydration always produce identical values.
 */

import type {
  Assessment,
  ClassGroup,
  Homework,
  Lesson,
  Student,
  Task,
} from './types'

/** Fixed "today" for the sample data (keeps alerts stable and SSR-safe). */
export const REFERENCE_DATE = '2026-11-10'
export const SCHOOL_YEAR = '2026 – 2027'
export const TEACHER_NAME = 'الأستاذ أحمد'
export const SCHOOL_NAME = 'الثانوية التأهيلية ابن رشد'

// ---------------------------------------------------------------- PRNG
function mulberry32(seed: number) {
  return () => {
    seed |= 0
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
const rand = mulberry32(20261110)
const pick = <T,>(list: readonly T[]) => list[Math.floor(rand() * list.length)]
const gauss = () => {
  const u = 1 - rand()
  const v = rand()
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v)
}
const clamp = (n: number, min: number, max: number) =>
  Math.min(max, Math.max(min, n))
const quarter = (n: number) => Math.round(n * 4) / 4

function addDays(iso: string, days: number) {
  const d = new Date(`${iso}T12:00:00Z`)
  d.setUTCDate(d.getUTCDate() + days)
  return d.toISOString().slice(0, 10)
}

// ---------------------------------------------------------------- الأقسام
export const classes: ClassGroup[] = [
  {
    id: 'tcs-2',
    code: 'جذع م. ع 2',
    name: 'الجذع المشترك العلمي 2',
    level: 'tc',
    size: 36,
    room: 'القاعة 14',
    weekdays: [1, 4],
    color: '#1f5f5b',
  },
  {
    id: 'tcl-1',
    code: 'جذع م. آ 1',
    name: 'الجذع المشترك آداب وعلوم إنسانية 1',
    level: 'tc',
    size: 34,
    room: 'القاعة 9',
    weekdays: [2, 5],
    color: '#b5562b',
  },
  {
    id: '1bse-3',
    code: '1 باك ع.ت 3',
    name: 'الأولى باكالوريا علوم تجريبية 3',
    level: '1bac',
    size: 38,
    room: 'القاعة 21',
    weekdays: [1, 3],
    color: '#c49a2c',
  },
  {
    id: '1bl-1',
    code: '1 باك آ 1',
    name: 'الأولى باكالوريا آداب 1',
    level: '1bac',
    size: 33,
    room: 'القاعة 9',
    weekdays: [3, 6],
    color: '#6b4e8a',
  },
  {
    id: '2bl-2',
    code: '2 باك آ 2',
    name: 'الثانية باكالوريا آداب 2',
    level: '2bac',
    size: 35,
    room: 'القاعة 17',
    weekdays: [2, 4],
    color: '#3f6d9b',
  },
]

// ---------------------------------------------------------------- الحصص
const BREAK_START = '2026-10-26'
const BREAK_END = '2026-11-01'
const FIRST_DAY = '2026-09-14'

/** Session dates already held for a class (two sessions per week). */
export function sessionDates(group: ClassGroup): string[] {
  const out: string[] = []
  for (let d = FIRST_DAY; d < REFERENCE_DATE; d = addDays(d, 1)) {
    if (d >= BREAK_START && d <= BREAK_END) continue
    const weekday = new Date(`${d}T12:00:00Z`).getUTCDay()
    if (group.weekdays.includes(weekday)) out.push(d)
  }
  return out
}

// ---------------------------------------------------------------- التقويمات
const assessmentTemplates = [
  {
    key: 'diag',
    title: 'التقويم التشخيصي',
    type: 'تقويم' as const,
    offset: 4,
  },
  {
    key: 'hw-grade',
    title: 'نقطة الأنشطة والواجبات',
    type: 'أنشطة' as const,
    offset: 30,
  },
  {
    key: 'f1',
    title: 'الفرض المحروس الأول',
    type: 'فرض' as const,
    offset: 37,
  },
]

export const assessments: Assessment[] = classes.flatMap((c, i) =>
  assessmentTemplates.map((t) => ({
    id: `${c.id}-${t.key}`,
    classId: c.id,
    title: t.title,
    type: t.type,
    date: addDays(FIRST_DAY, t.offset + i),
  })),
)

// ---------------------------------------------------------------- الواجبات
const homeworkTitles: Record<ClassGroup['level'], string[]> = {
  tc: [
    'تلخيص نص «قيمة الوقت»',
    'تمارين الجملة الاسمية والفعلية',
    'تحرير فقرة وصفية',
    'إعراب أبيات مختارة',
  ],
  '1bac': [
    'تحليل قصيدة جاهلية: البنية والإيقاع',
    'بطاقة قراءة: المعلقات',
    'تمارين الأساليب الإنشائية',
    'إنشاء: مقارنة بين نصين',
  ],
  '2bac': [
    'تحليل نص من شعر إحياء النموذج',
    'بطاقة قراءة: ظاهرة الشعر الحديث',
    'تمارين الحجاج والاستدلال',
    'إنشاء: مقدمة تحليل نص شعري',
  ],
}

export const homework: Homework[] = classes.flatMap((c, ci) =>
  homeworkTitles[c.level].map((title, i) => ({
    id: `${c.id}-hw${i + 1}`,
    classId: c.id,
    title,
    assigned: addDays(FIRST_DAY, 6 + i * 13 + ci),
    due: addDays(FIRST_DAY, 12 + i * 13 + ci),
  })),
)

// ---------------------------------------------------------------- التلاميذ
const maleNames = [
  'يوسف', 'محمد', 'أيوب', 'حمزة', 'عمر', 'إلياس', 'أنس', 'زكرياء', 'ياسين',
  'آدم', 'مهدي', 'سفيان', 'إسماعيل', 'عثمان', 'بلال', 'رضا', 'نزار', 'وليد',
  'هشام', 'طه', 'إدريس', 'مروان', 'أسامة', 'صلاح الدين', 'عبد الرحيم',
]
const femaleNames = [
  'سلمى', 'هبة', 'مريم', 'خديجة', 'فاطمة الزهراء', 'آية', 'إيمان', 'هاجر',
  'نهيلة', 'سارة', 'ياسمين', 'شيماء', 'أسماء', 'رانيا', 'دعاء', 'كوثر', 'لبنى',
  'نور الهدى', 'زينب', 'وئام', 'سكينة', 'غيثة', 'جيهان', 'رميساء', 'إكرام',
]
const familyNames = [
  'العلوي', 'بنعلي', 'الإدريسي', 'التازي', 'الفاسي', 'بنكيران', 'الصديقي',
  'الحسني', 'الشرقاوي', 'المرابط', 'الوزاني', 'أمزيان', 'أوعلي', 'بوزيان',
  'الرحماني', 'السوسي', 'الزياني', 'الكتاني', 'بلحاج', 'العمراني', 'الغزواني',
  'المنصوري', 'الدكالي', 'الطاهري', 'بنموسى', 'الريفي', 'الخطابي', 'أيت باها',
  'السباعي', 'الناصري', 'القادري', 'الجراري', 'لحلو', 'بنجلون', 'الزموري',
]

const positiveNotes = [
  'مبادرة متميزة في قراءة النص وشرحه',
  'ساعد زملاءه في إنجاز نشاط جماعي',
  'عرض شفهي متقن حول الصورة الشعرية',
  'التزام واضح وتحسن ملحوظ في الانضباط',
  'تعليق نقدي جيد أثناء المناقشة',
]
const negativeNotes = [
  'إخلال بالنظام داخل القسم',
  'استعمال الهاتف أثناء الحصة',
  'تأخر متكرر عن بداية الحصة',
  'عدم إحضار الكتاب المدرسي والدفتر',
  'عدم احترام التعليمات أثناء الفرض',
]

const months = ['2026-09', '2026-10', '2026-11']

export const students: Student[] = classes.flatMap((group) => {
  const sessions = sessionDates(group)
  const classAssessments = assessments.filter((a) => a.classId === group.id)
  const classHomework = homework.filter((h) => h.classId === group.id)
  const levelShift = group.level === '2bac' ? 0.6 : group.level === 'tc' ? -0.4 : 0

  return Array.from({ length: group.size }, (_, index) => {
    const gender: 'ذ' | 'أ' = rand() < 0.52 ? 'أ' : 'ذ'
    const firstName = gender === 'أ' ? pick(femaleNames) : pick(maleNames)
    const lastName = pick(familyNames)
    const ability = clamp(12.5 + levelShift + gauss() * 2.6, 4, 18.5)
    const diligence = clamp(0.62 + gauss() * 0.22, 0, 1)

    // النقط: قد يتراجع بعض التلاميذ أو يتحسنون بين التقويمات
    const drift = gauss() * 0.9
    const grades = classAssessments.map((a, i) => ({
      assessmentId: a.id,
      score: clamp(
        quarter(
          ability +
            drift * (i - 1) +
            (a.type === 'أنشطة' ? (diligence - 0.5) * 5 : 0) +
            gauss() * 1.3,
        ),
        1,
        19.75,
      ),
    }))

    // الغياب والتأخر
    const absenceRate = clamp(0.06 - (diligence - 0.62) * 0.16, 0.005, 0.28)
    const attendance = sessions.flatMap((date) => {
      const r = rand()
      if (r < absenceRate)
        return [{ date, status: 'غائب' as const, justified: rand() < 0.35 }]
      if (r < absenceRate + 0.03)
        return [{ date, status: 'متأخر' as const, justified: false }]
      return []
    })

    // الواجبات المنزلية
    const homeworkStatus = classHomework.map((h) => {
      const r = rand()
      const status =
        r < diligence * 0.7 + 0.32
          ? ('منجز' as const)
          : r < diligence * 0.7 + 0.45
            ? ('متأخر' as const)
            : ('غير منجز' as const)
      return { homeworkId: h.id, status }
    })

    // السلوك والانضباط
    const behavior: Student['behavior'] = []
    const negCount = rand() < 0.75 - diligence * 0.5 ? (rand() < 0.4 ? 2 : 1) : 0
    const posCount = rand() < diligence * 0.6 ? 1 : 0
    for (let i = 0; i < negCount; i++)
      behavior.push({
        date: pick(sessions),
        kind: 'سلبي',
        note: pick(negativeNotes),
      })
    for (let i = 0; i < posCount; i++)
      behavior.push({
        date: pick(sessions),
        kind: 'إيجابي',
        note: pick(positiveNotes),
      })
    behavior.sort((a, b) => a.date.localeCompare(b.date))

    // المشاركة (تقدير شهري من 10)
    const participation = months.map((month) => ({
      month,
      score: clamp(
        Math.round(4 + diligence * 4 + (ability - 11) * 0.25 + gauss() * 1.2),
        1,
        10,
      ),
    }))

    const n = String(index + 1).padStart(2, '0')
    return {
      id: `${group.id}-${n}`,
      massar: `${gender === 'أ' ? 'K' : 'J'}1${String(3040000 + Math.floor(rand() * 899999))}`,
      firstName,
      lastName,
      gender,
      classId: group.id,
      seat: index + 1,
      birthDate: addDays(
        group.level === 'tc' ? '2010-01-01' : group.level === '1bac' ? '2009-01-01' : '2008-01-01',
        Math.floor(rand() * 520),
      ),
      guardianPhone: `06${String(10000000 + Math.floor(rand() * 89999999))}`,
      grades,
      attendance,
      homework: homeworkStatus,
      behavior,
      participation,
    } satisfies Student
  })
})

// ---------------------------------------------------------------- التوزيع السنوي
type LessonSeed = [unit: string, title: string, component: Lesson['component']]

const programs: Record<ClassGroup['level'], LessonSeed[]> = {
  tc: [
    ['المجزوءة الأولى: الإنسان والقيم', 'نص: قيمة الوقت', 'نصوص'],
    ['المجزوءة الأولى: الإنسان والقيم', 'الجملة الاسمية والفعلية', 'علوم اللغة'],
    ['المجزوءة الأولى: الإنسان والقيم', 'مهارة التلخيص', 'تعبير وإنشاء'],
    ['المجزوءة الأولى: الإنسان والقيم', 'نص شعري: في مدح الأخلاق', 'نصوص'],
    ['المجزوءة الأولى: الإنسان والقيم', 'التوابع: النعت والعطف', 'علوم اللغة'],
    ['المجزوءة الأولى: الإنسان والقيم', 'مهارة الوصف', 'تعبير وإنشاء'],
    ['المجزوءة الثانية: الحضارة والمجتمع', 'نص: أصالة الحضارة المغربية', 'نصوص'],
    ['المجزوءة الثانية: الحضارة والمجتمع', 'أسلوب الاستفهام', 'علوم اللغة'],
    ['المجزوءة الثانية: الحضارة والمجتمع', 'مهارة السرد', 'تعبير وإنشاء'],
    ['المجزوءة الثانية: الحضارة والمجتمع', 'نص: المدينة والتحولات', 'نصوص'],
    ['المجزوءة الثانية: الحضارة والمجتمع', 'أسلوب النداء', 'علوم اللغة'],
    ['المجزوءة الثالثة: الأدب والفن', 'نص قصصي: حكاية من التراث', 'نصوص'],
    ['المجزوءة الثالثة: الأدب والفن', 'الأفعال الخمسة', 'علوم اللغة'],
    ['المجزوءة الثالثة: الأدب والفن', 'مهارة الحوار', 'تعبير وإنشاء'],
    ['المجزوءة الثالثة: الأدب والفن', 'نص: الفن والحياة', 'نصوص'],
    ['المجزوءة الثالثة: الأدب والفن', 'التقويم والدعم', 'تقويم'],
  ],
  '1bac': [
    ['النصوص الشعرية: الأدب الجاهلي', 'مدخل: خصائص الشعر الجاهلي', 'نصوص'],
    ['النصوص الشعرية: الأدب الجاهلي', 'نص: من معلقة زهير بن أبي سلمى', 'نصوص'],
    ['النصوص الشعرية: الأدب الجاهلي', 'الحقول الدلالية', 'علوم اللغة'],
    ['النصوص الشعرية: الأدب الجاهلي', 'مهارة تحليل الإيقاع', 'تعبير وإنشاء'],
    ['النصوص الشعرية: الأدب الإسلامي والأموي', 'نص: شعر الدعوة الإسلامية', 'نصوص'],
    ['النصوص الشعرية: الأدب الإسلامي والأموي', 'الأساليب الإنشائية', 'علوم اللغة'],
    ['النصوص الشعرية: الأدب الإسلامي والأموي', 'نص: الغزل العذري', 'نصوص'],
    ['النصوص الشعرية: الأدب الإسلامي والأموي', 'مهارة المقارنة', 'تعبير وإنشاء'],
    ['النصوص الشعرية: الأدب العباسي', 'نص: التجديد عند أبي نواس', 'نصوص'],
    ['النصوص الشعرية: الأدب العباسي', 'التشبيه والاستعارة', 'علوم اللغة'],
    ['النصوص الشعرية: الأدب العباسي', 'نص: حكمة المتنبي', 'نصوص'],
    ['النصوص الشعرية: الأدب العباسي', 'مهارة التركيب', 'تعبير وإنشاء'],
    ['النصوص الشعرية: الأدب الأندلسي', 'نص: الموشحات', 'نصوص'],
    ['النصوص الشعرية: الأدب الأندلسي', 'الكناية والمجاز', 'علوم اللغة'],
    ['النصوص الشعرية: الأدب الأندلسي', 'نص: رثاء المدن', 'نصوص'],
    ['النصوص الشعرية: الأدب الأندلسي', 'التقويم والدعم', 'تقويم'],
  ],
  '2bac': [
    ['مجزوءة ظاهرة الشعر الحديث', 'مدخل: ظاهرة الشعر الحديث', 'نصوص'],
    ['مجزوءة ظاهرة الشعر الحديث', 'إحياء النموذج: محمود سامي البارودي', 'نصوص'],
    ['مجزوءة ظاهرة الشعر الحديث', 'الحجاج: المفهوم والآليات', 'علوم اللغة'],
    ['مجزوءة ظاهرة الشعر الحديث', 'مهارة تحليل نص شعري', 'تعبير وإنشاء'],
    ['مجزوءة ظاهرة الشعر الحديث', 'سؤال الذات: أبو القاسم الشابي', 'نصوص'],
    ['مجزوءة ظاهرة الشعر الحديث', 'الاتساق والانسجام', 'علوم اللغة'],
    ['مجزوءة ظاهرة الشعر الحديث', 'تكسير البنية: بدر شاكر السياب', 'نصوص'],
    ['مجزوءة ظاهرة الشعر الحديث', 'مهارة صياغة المقدمة والخاتمة', 'تعبير وإنشاء'],
    ['مجزوءة ظاهرة الشعر الحديث', 'تحديث الرؤيا: أدونيس', 'نصوص'],
    ['مجزوءة ظاهرة الشعر الحديث', 'الصورة الشعرية الحديثة', 'علوم اللغة'],
    ['مجزوءة الأشكال النثرية الحديثة', 'القصة: عناصر البناء', 'نصوص'],
    ['مجزوءة الأشكال النثرية الحديثة', 'مهارة التحليل السردي', 'تعبير وإنشاء'],
    ['مجزوءة الأشكال النثرية الحديثة', 'الرواية: مدخل وقراءة نص', 'نصوص'],
    ['مجزوءة الأشكال النثرية الحديثة', 'الأسلوب الحجاجي في المقالة', 'علوم اللغة'],
    ['مجزوءة الأشكال النثرية الحديثة', 'المسرحية: الحوار والصراع', 'نصوص'],
    ['مجزوءة الأشكال النثرية الحديثة', 'التقويم والدعم', 'تقويم'],
  ],
}

/** How many lessons each class has actually finished (sample). */
const completedByClass: Record<string, number> = {
  'tcs-2': 7,
  'tcl-1': 8,
  '1bse-3': 6,
  '1bl-1': 8,
  '2bl-2': 5,
}

export const lessons: Lesson[] = classes.flatMap((c, ci) =>
  programs[c.level].map(([unit, title, component], i) => {
    const planned = addDays('2026-09-17', i * 7 + (i >= 6 ? 7 : 0) + ci)
    const done = i < completedByClass[c.id]
    return {
      id: `${c.id}-l${i + 1}`,
      classId: c.id,
      order: i + 1,
      unit,
      title,
      component,
      plannedDate: planned,
      doneDate: done ? addDays(planned, Math.floor(rand() * 5) - 1) : null,
    }
  }),
)

// ---------------------------------------------------------------- المهام
export const tasks: Task[] = [
  // تحضير الدروس (مهام متكررة أسبوعياً)
  ...classes.map((c, i) => {
    const next = lessons.find((l) => l.classId === c.id && !l.doneDate)
    return {
      id: `prep-${c.id}`,
      title: `تحضير درس: ${next?.title ?? 'حصة الدعم'}`,
      category: 'تحضير الدروس' as const,
      classId: c.id,
      due: addDays(REFERENCE_DATE, i - 2),
      recurrence: 'أسبوعية' as const,
      done: false,
      notes: 'الجذاذة، الوسائل الديداكتيكية، أسئلة الفهم',
    }
  }),
  {
    id: 't-corr-1bse',
    title: 'تصحيح أوراق الفرض الأول',
    category: 'التصحيح',
    classId: '1bse-3',
    due: '2026-11-06',
    recurrence: null,
    done: false,
    notes: '38 ورقة — إعادة الأوراق مع التصحيح الجماعي',
  },
  {
    id: 't-corr-2bl',
    title: 'تصحيح أوراق الفرض الأول',
    category: 'التصحيح',
    classId: '2bl-2',
    due: '2026-11-12',
    recurrence: null,
    done: false,
    notes: null,
  },
  {
    id: 't-massar',
    title: 'إدخال نقط الفرض الأول في منظومة مسار',
    category: 'إداري',
    classId: null,
    due: '2026-11-08',
    recurrence: null,
    done: false,
    notes: 'الأقسام الخمسة',
  },
  {
    id: 't-f2',
    title: 'إعداد موضوع الفرض المحروس الثاني',
    category: 'الفروض والتقويم',
    classId: 'tcs-2',
    due: '2026-11-20',
    recurrence: null,
    done: false,
    notes: 'نص + أسئلة الفهم والتحليل + الإنشاء',
  },
  {
    id: 't-support',
    title: 'إعداد حصة دعم للتلاميذ المتعثرين',
    category: 'الدعم والمعالجة',
    classId: '1bl-1',
    due: '2026-11-14',
    recurrence: null,
    done: false,
    notes: 'تمارين في الأساليب الإنشائية',
  },
  {
    id: 't-council',
    title: 'تحضير تقرير مجلس القسم',
    category: 'إداري',
    classId: null,
    due: '2026-11-25',
    recurrence: null,
    done: false,
    notes: null,
  },
  {
    id: 't-parents',
    title: 'التواصل مع أولياء التلاميذ كثيري الغياب',
    category: 'التواصل',
    classId: null,
    due: '2026-11-09',
    recurrence: null,
    done: false,
    notes: 'عبر الحراسة العامة',
  },
  {
    id: 't-cahier',
    title: 'تحيين دفتر النصوص',
    category: 'إداري',
    classId: null,
    due: '2026-11-13',
    recurrence: 'أسبوعية',
    done: false,
    notes: null,
  },
  {
    id: 't-hw-check',
    title: 'تتبع الواجب المنزلي: تمارين الحجاج',
    category: 'التصحيح',
    classId: '2bl-2',
    due: '2026-11-03',
    recurrence: null,
    done: true,
    notes: null,
  },
  {
    id: 't-diag-report',
    title: 'تحليل نتائج التقويم التشخيصي',
    category: 'الفروض والتقويم',
    classId: null,
    due: '2026-10-02',
    recurrence: null,
    done: true,
    notes: null,
  },
]
