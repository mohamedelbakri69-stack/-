import { createFileRoute } from '@tanstack/react-router'
import { AlarmClock, Check, Plus, Repeat, Trash2 } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { PageHeader, Pill } from '../components/ui'
import { dueLabel, formatDate, getClass, taskState, type TaskState } from '../lib/analytics'
import { classes, REFERENCE_DATE } from '../lib/fixtures'
import { useStore } from '../lib/store'
import type { Task, TaskCategory } from '../lib/types'

export const Route = createFileRoute('/tasks')({ component: Tasks })

const categories: TaskCategory[] = [
  'تحضير الدروس',
  'التصحيح',
  'الفروض والتقويم',
  'الدعم والمعالجة',
  'إداري',
  'التواصل',
]
const groups: { state: TaskState; title: string }[] = [
  { state: 'متأخرة', title: 'متأخرة' },
  { state: 'اليوم', title: 'اليوم' },
  { state: 'هذا الأسبوع', title: 'خلال الأيام السبعة القادمة' },
  { state: 'لاحقاً', title: 'لاحقاً' },
  { state: 'منجزة', title: 'منجزة' },
]

function Tasks() {
  const { tasks, toggleTask, removeTask } = useStore()
  const [category, setCategory] = useState<TaskCategory | null>(null)
  const [adding, setAdding] = useState(false)

  const visible = tasks
    .filter((t) => !category || t.category === category)
    .sort((a, b) => a.due.localeCompare(b.due))
  const overdueCount = tasks.filter((t) => taskState(t).state === 'متأخرة').length
  const recurring = tasks.filter((t) => t.recurrence && !t.done).length

  return (
    <div className="mx-auto max-w-[64rem]">
      <PageHeader
        eyebrow="تتبع المهام"
        title="المهام"
        actions={
          <button
            onClick={() => setAdding((v) => !v)}
            className="flex items-center gap-2 rounded-xl bg-teal-deep px-4 py-2.5 text-sm font-medium text-paper transition hover:bg-teal"
          >
            <Plus className="size-4" /> مهمة جديدة
          </button>
        }
      >
        بدون أولويات: كل مهمة لها أجل، والمتأخرة تظهر أولاً مع تنبيه. المهام المتكررة (مثل تحضير الدروس) تُجدول تلقائياً للأسبوع الموالي عند إنجازها.
      </PageHeader>

      {overdueCount ? (
        <div className="rise mb-5 flex items-center gap-3 rounded-2xl border border-bad/25 bg-bad-soft/70 p-4 text-bad">
          <AlarmClock className="size-5" />
          <p className="font-semibold">
            لديك <span className="num">{overdueCount}</span> مهام تجاوزت أجلها
          </p>
          <span className="ms-auto text-xs opacity-80">
            <Repeat className="me-1 inline size-3.5" />
            <span className="num">{recurring}</span> مهام متكررة نشطة
          </span>
        </div>
      ) : null}

      {adding ? <NewTask onDone={() => setAdding(false)} /> : null}

      <div className="no-print mb-6 flex flex-wrap gap-1.5">
        <FilterChip active={!category} onClick={() => setCategory(null)}>
          الكل
        </FilterChip>
        {categories.map((c) => (
          <FilterChip key={c} active={category === c} onClick={() => setCategory(c)}>
            {c}
          </FilterChip>
        ))}
      </div>

      <div className="space-y-7">
        {groups.map(({ state, title }) => {
          const list = visible.filter((t) => taskState(t).state === state)
          if (!list.length) return null
          return (
            <section key={state} className="rise">
              <h2 className={`mb-3 flex items-center gap-2 text-lg ${state === 'متأخرة' ? 'text-bad' : 'text-ink'}`}>
                {title} <span className="num text-sm text-ink-faint">({list.length})</span>
              </h2>
              <ul className="card divide-y divide-line/70 overflow-hidden">
                {list.map((t) => (
                  <TaskRow key={t.id} task={t} onToggle={() => toggleTask(t.id)} onRemove={() => removeTask(t.id)} />
                ))}
              </ul>
            </section>
          )
        })}
        {!visible.length ? (
          <p className="card p-10 text-center text-ink-faint">لا توجد مهام في هذا التصنيف.</p>
        ) : null}
      </div>
    </div>
  )
}

function TaskRow({ task, onToggle, onRemove }: { task: Task; onToggle: () => void; onRemove: () => void }) {
  const { state } = taskState(task)
  const group = task.classId ? getClass(task.classId) : null
  return (
    <li className={`group flex items-start gap-3 px-4 py-3.5 ${state === 'متأخرة' ? 'bg-bad-soft/30' : ''}`}>
      <button
        onClick={onToggle}
        aria-label={task.done ? 'إلغاء الإنجاز' : 'تحديد كمنجزة'}
        className={`mt-0.5 grid size-6 shrink-0 place-items-center rounded-lg border-2 transition ${
          task.done ? 'border-good bg-good text-white' : state === 'متأخرة' ? 'border-bad/60 hover:bg-bad-soft' : 'border-line hover:border-teal'
        }`}
      >
        {task.done ? <Check className="size-4" strokeWidth={3} /> : null}
      </button>
      <div className="min-w-0 flex-1">
        <p className={`leading-6 ${task.done ? 'text-ink-faint line-through' : 'text-ink'}`}>{task.title}</p>
        <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-ink-faint">
          <Pill>{task.category}</Pill>
          {group ? (
            <span className="inline-flex items-center gap-1">
              <span className="size-2 rounded-full" style={{ background: group.color }} /> {group.code}
            </span>
          ) : null}
          {task.recurrence ? (
            <Pill tone="teal">
              <Repeat className="size-3" /> {task.recurrence}
            </Pill>
          ) : null}
          {task.notes ? <span>· {task.notes}</span> : null}
        </div>
      </div>
      <div className="shrink-0 text-end">
        <p className="text-sm text-ink-soft">{formatDate(task.due, true)}</p>
        <p className={`text-xs ${state === 'متأخرة' ? 'font-semibold text-bad' : 'text-ink-faint'}`}>{dueLabel(task)}</p>
      </div>
      <button
        onClick={onRemove}
        aria-label="حذف المهمة"
        className="no-print mt-0.5 rounded-lg p-1.5 text-ink-faint opacity-0 transition group-hover:opacity-100 hover:bg-bad-soft hover:text-bad focus-visible:opacity-100"
      >
        <Trash2 className="size-4" />
      </button>
    </li>
  )
}

function NewTask({ onDone }: { onDone: () => void }) {
  const { addTask } = useStore()
  const [error, setError] = useState<string | null>(null)

  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const data = new FormData(e.currentTarget)
    const title = String(data.get('title') ?? '').trim()
    const due = String(data.get('due') ?? '')
    if (!title) return setError('اكتب عنوان المهمة')
    if (!due) return setError('حدد أجل المهمة')
    addTask({
      title,
      due,
      category: data.get('category') as TaskCategory,
      classId: (data.get('classId') as string) || null,
      recurrence: data.get('recurring') ? 'أسبوعية' : null,
      notes: String(data.get('notes') ?? '').trim() || null,
    })
    onDone()
  }

  const field = 'w-full rounded-xl border border-line bg-paper/60 px-3 py-2 text-sm outline-none focus:border-teal'
  return (
    <form onSubmit={submit} className="card rise mb-6 grid gap-3 p-5 sm:grid-cols-2">
      <label className="sm:col-span-2">
        <span className="mb-1 block text-sm text-ink-soft">عنوان المهمة</span>
        <input name="title" autoFocus className={field} placeholder="مثال: تحضير درس الحجاج" />
      </label>
      <label>
        <span className="mb-1 block text-sm text-ink-soft">التصنيف</span>
        <select name="category" className={field} defaultValue="تحضير الدروس">
          {categories.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </label>
      <label>
        <span className="mb-1 block text-sm text-ink-soft">القسم</span>
        <select name="classId" className={field} defaultValue="">
          <option value="">جميع الأقسام / عام</option>
          {classes.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </label>
      <label>
        <span className="mb-1 block text-sm text-ink-soft">الأجل</span>
        <input name="due" type="date" defaultValue={REFERENCE_DATE} className={field} />
      </label>
      <label>
        <span className="mb-1 block text-sm text-ink-soft">ملاحظات</span>
        <input name="notes" className={field} placeholder="اختياري" />
      </label>
      <label className="flex items-center gap-2 text-sm text-ink-soft">
        <input type="checkbox" name="recurring" className="size-4 accent-teal" /> مهمة متكررة أسبوعياً
      </label>
      <div className="flex items-center justify-end gap-2">
        {error ? <p role="alert" className="me-auto text-sm text-bad">{error}</p> : null}
        <button type="button" onClick={onDone} className="rounded-xl px-4 py-2 text-sm text-ink-soft hover:bg-paper-2">
          إلغاء
        </button>
        <button className="rounded-xl bg-teal-deep px-5 py-2 text-sm font-medium text-paper hover:bg-teal">إضافة</button>
      </div>
    </form>
  )
}

function FilterChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-lg px-3 py-1.5 text-sm transition ${active ? 'bg-teal-deep text-paper' : 'bg-card text-ink-soft hover:bg-paper-2'}`}
    >
      {children}
    </button>
  )
}
