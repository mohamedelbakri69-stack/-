import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { Download, Search, TriangleAlert } from 'lucide-react'
import { useMemo } from 'react'
import { Avatar, PageHeader, Pill, ScoreBadge } from '../components/ui'
import {
  formatPercent,
  formatScore,
  isStruggling,
  RISK_RULES,
  summaries,
  type StudentSummary,
} from '../lib/analytics'
import { classes } from '../lib/fixtures'

type Search = { classId?: string; filter?: 'struggling'; q?: string; sort?: SortKey }
type SortKey = 'seat' | 'average' | 'absences' | 'homework' | 'participation'

export const Route = createFileRoute('/students/')({
  validateSearch: (search: Record<string, unknown>): Search => ({
    classId: classes.some((c) => c.id === search.classId) ? (search.classId as string) : undefined,
    filter: search.filter === 'struggling' ? 'struggling' : undefined,
    q: typeof search.q === 'string' && search.q ? search.q : undefined,
    sort: ['average', 'absences', 'homework', 'participation'].includes(search.sort as string)
      ? (search.sort as SortKey)
      : undefined,
  }),
  component: Students,
})

const sorters: Record<SortKey, (a: StudentSummary, b: StudentSummary) => number> = {
  seat: (a, b) => a.group.id.localeCompare(b.group.id) || a.student.seat - b.student.seat,
  average: (a, b) => (a.average ?? 0) - (b.average ?? 0),
  absences: (a, b) => b.absences - a.absences,
  homework: (a, b) => b.homeworkMissing - a.homeworkMissing,
  participation: (a, b) => a.participation - b.participation,
}

function Students() {
  const { classId, filter, q, sort = 'seat' } = Route.useSearch()
  const navigate = useNavigate({ from: '/students/' })
  const set = (patch: Partial<Search>) =>
    navigate({ search: (prev) => ({ ...prev, ...patch }), replace: true })

  const rows = useMemo(() => {
    const needle = q?.trim()
    return summaries
      .filter((s) => !classId || s.group.id === classId)
      .filter((s) => filter !== 'struggling' || isStruggling(s))
      .filter((s) => !needle || s.fullName.includes(needle) || s.student.massar.includes(needle.toUpperCase()))
      .sort(sorters[sort])
  }, [classId, filter, q, sort])

  const scope = summaries.filter((s) => !classId || s.group.id === classId)
  const strugglingInScope = scope.filter(isStruggling).length

  function exportList() {
    const header = ['الرقم', 'الاسم', 'رقم مسار', 'القسم', 'المعدل', 'الغياب', 'غير مبرر', 'الواجبات', 'المشاركة', 'مؤشرات التعثر']
    const lines = rows.map((s) => [
      s.student.seat, s.fullName, s.student.massar, s.group.code, formatScore(s.average),
      s.absences, s.unjustified, `${s.homeworkDone}/${s.homeworkTotal}`, formatScore(s.participation),
      s.reasons.map((r) => r.label).join('، '),
    ])
    const csv = [header, ...lines]
      .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(','))
      .join('\r\n')
    const url = URL.createObjectURL(new Blob([`﻿${csv}`], { type: 'text/csv;charset=utf-8' }))
    const a = Object.assign(document.createElement('a'), { href: url, download: 'قائمة-التلاميذ.csv' })
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="mx-auto max-w-[88rem]">
      <PageHeader
        eyebrow="متابعة التلاميذ"
        title={classId ? classes.find((c) => c.id === classId)!.name : 'جميع التلاميذ'}
        actions={
          <button
            onClick={exportList}
            className="flex items-center gap-2 rounded-xl border border-line bg-card px-4 py-2.5 text-sm font-medium transition hover:border-teal/50"
          >
            <Download className="size-4" /> تحميل القائمة
          </button>
        }
      >
        النقط، الحضور والغياب، الواجبات المنزلية، السلوك والمشاركة لكل تلميذ. اضغط على أي تلميذ لفتح ملفه الشخصي.
      </PageHeader>

      {/* المرشحات */}
      <div className="no-print card rise mb-5 flex flex-wrap items-center gap-3 p-3">
        <div className="flex flex-wrap gap-1.5">
          <Chip active={!classId} onClick={() => set({ classId: undefined })}>
            الكل <span className="num opacity-60">{summaries.length}</span>
          </Chip>
          {classes.map((c) => (
            <Chip key={c.id} active={classId === c.id} onClick={() => set({ classId: c.id })} color={c.color}>
              {c.code} <span className="num opacity-60">{c.size}</span>
            </Chip>
          ))}
        </div>
        <label className="relative ms-auto min-w-56 flex-1 sm:max-w-72">
          <span className="sr-only">بحث</span>
          <Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
          <input
            value={q ?? ''}
            onChange={(e) => set({ q: e.target.value || undefined })}
            placeholder="بحث بالاسم أو رقم مسار"
            className="w-full rounded-xl border border-line bg-paper/60 py-2 ps-9 pe-3 text-sm outline-none focus:border-teal"
          />
        </label>
        <button
          onClick={() => set({ filter: filter ? undefined : 'struggling' })}
          aria-pressed={filter === 'struggling'}
          className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-medium transition ${
            filter ? 'bg-clay text-white' : 'bg-clay-soft text-clay hover:bg-clay/15'
          }`}
        >
          <TriangleAlert className="size-4" /> المتعثرون فقط
          <span className="num rounded-full bg-white/25 px-1.5 text-xs">{strugglingInScope}</span>
        </button>
        <label className="flex items-center gap-2 text-sm text-ink-soft">
          ترتيب حسب
          <select
            value={sort}
            onChange={(e) => set({ sort: e.target.value === 'seat' ? undefined : (e.target.value as SortKey) })}
            className="rounded-lg border border-line bg-paper/60 px-2 py-1.5 text-sm"
          >
            <option value="seat">رقم الترتيب</option>
            <option value="average">المعدل (الأضعف أولاً)</option>
            <option value="absences">الغياب (الأكثر أولاً)</option>
            <option value="homework">الواجبات غير المنجزة</option>
            <option value="participation">المشاركة (الأضعف أولاً)</option>
          </select>
        </label>
      </div>

      {filter ? (
        <p className="rise mb-4 rounded-xl bg-clay-soft/60 px-4 py-3 text-sm leading-7 text-clay">
          يُعتبر التلميذ متعثراً إذا كان معدله دون {RISK_RULES.average}، أو اجتمع لديه مؤشران أو أكثر من:{' '}
          {RISK_RULES.unjustifiedAbsences} غيابات غير مبررة، {RISK_RULES.missingHomework} واجبات غير منجزة،{' '}
          {RISK_RULES.negativeBehavior} ملاحظات سلوكية، تراجع بـ {RISK_RULES.gradeDrop} نقط بين التقويمين، أو مشاركة دون{' '}
          {RISK_RULES.participation}/10.
        </p>
      ) : null}

      <div className="card rise overflow-hidden" style={{ animationDelay: '80ms' }}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[56rem] text-sm">
            <thead className="bg-paper-2/60 text-xs text-ink-soft">
              <tr>
                <th className="px-4 py-3 text-start font-medium">التلميذ</th>
                <th className="px-3 py-3 text-start font-medium">القسم</th>
                <th className="px-3 py-3 font-medium">المعدل</th>
                <th className="px-3 py-3 font-medium">الحضور</th>
                <th className="px-3 py-3 font-medium">الغياب (غ.م)</th>
                <th className="px-3 py-3 font-medium">الواجبات</th>
                <th className="px-3 py-3 font-medium">السلوك</th>
                <th className="px-3 py-3 font-medium">المشاركة</th>
                <th className="px-4 py-3 text-start font-medium">التنبيهات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line/70">
              {rows.map((s) => (
                <tr key={s.student.id} className="transition hover:bg-paper/70">
                  <td className="px-4 py-2.5">
                    <Link
                      to="/students/$studentId"
                      params={{ studentId: s.student.id }}
                      className="flex items-center gap-3 font-medium hover:text-teal"
                    >
                      <Avatar name={s.student.firstName} color={s.group.color} />
                      <span>
                        <span className="block">{s.fullName}</span>
                        <span className="num block text-start text-xs font-normal text-ink-faint">{s.student.massar}</span>
                      </span>
                    </Link>
                  </td>
                  <td className="px-3 py-2.5 text-ink-soft">{s.group.code}</td>
                  <td className="px-3 py-2.5 text-center"><ScoreBadge score={s.average} /></td>
                  <td className="num px-3 py-2.5 text-center">{formatPercent(s.attendanceRate)}</td>
                  <td className="px-3 py-2.5 text-center">
                    <span className="num">{s.absences}</span>{' '}
                    <span className={`num text-xs ${s.unjustified >= RISK_RULES.unjustifiedAbsences ? 'text-bad font-semibold' : 'text-ink-faint'}`}>({s.unjustified})</span>
                  </td>
                  <td className={`num px-3 py-2.5 text-center ${s.homeworkMissing >= 2 ? 'text-bad font-semibold' : ''}`}>
                    {s.homeworkDone}/{s.homeworkTotal}
                  </td>
                  <td className="px-3 py-2.5 text-center">
                    {s.negative ? <Pill tone="bad">−{s.negative}</Pill> : null}{' '}
                    {s.positive ? <Pill tone="good">+{s.positive}</Pill> : null}
                    {!s.negative && !s.positive ? <span className="text-ink-faint">—</span> : null}
                  </td>
                  <td className="num px-3 py-2.5 text-center">{formatScore(s.participation)}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex flex-wrap gap-1">
                      {isStruggling(s) ? <Pill tone="bad">متعثر</Pill> : null}
                      {s.reasons.slice(0, 2).map((r) => (
                        <Pill key={r.key} tone="warn">{r.label}</Pill>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!rows.length ? (
          <p className="p-10 text-center text-ink-faint">لا يوجد تلاميذ يطابقون هذا البحث.</p>
        ) : (
          <p className="border-t border-line px-4 py-3 text-xs text-ink-faint">
            <span className="num">{rows.length}</span> تلميذاً معروضاً
          </p>
        )}
      </div>
    </div>
  )
}

function Chip({
  active,
  onClick,
  color,
  children,
}: {
  active: boolean
  onClick: () => void
  color?: string
  children: React.ReactNode
}) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm transition ${
        active ? 'bg-teal-deep text-paper' : 'text-ink-soft hover:bg-paper-2'
      }`}
    >
      {color ? <span className="size-2 rounded-full" style={{ background: color }} /> : null}
      {children}
    </button>
  )
}
