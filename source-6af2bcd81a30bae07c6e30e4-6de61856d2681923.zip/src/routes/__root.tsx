import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'
import { AppShell } from '../components/AppShell'
import { StoreProvider } from '../lib/store'

import '../styles.css'

const siteName = 'مِداد — لوحة أستاذ اللغة العربية'
const siteDescription =
  'لوحة تحكم لأستاذ اللغة العربية بالثانوي التأهيلي: إحصائيات الأقسام، متابعة التلاميذ نقطاً وحضوراً وسلوكاً، تنبيه المتعثرين، التوزيع السنوي، والمهام المتأخرة.'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: siteName },
      { name: 'description', content: siteDescription },
      { property: 'og:title', content: siteName },
      { property: 'og:description', content: siteDescription },
      { property: 'og:type', content: 'website' },
      { name: 'theme-color', content: '#142f2d' },
    ],
    links: [
      { rel: 'icon', type: 'image/svg+xml', href: '/favicon.svg' },
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&family=Reem+Kufi:wght@400;500;600;700&display=swap',
      },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <HeadContent />
      </head>
      <body>
        <StoreProvider>
          <AppShell>{children}</AppShell>
        </StoreProvider>
        <Scripts />
      </body>
    </html>
  )
}
