import { createFileRoute, Link, notFound } from '@tanstack/react-router'
import {
  ArrowRight,
  CalendarX2,
  ClipboardList,
  Download,
  GraduationCap,
  Hand,
  Printer,
  ShieldCheck,
  TriangleAlert,
} from 'lucide-react'
import { useState } from 'react'
import { StudentGradesChart } from '../components/charts'
import { PageHeader, Pill, ScoreBadge, SectionTitle, StatTile } from '../components/ui'
import {
  formatDate,
  formatMonth,
  formatPercent,
  formatScore,
  getAssessment,
  getHomework,
  getSummary,
  isStruggling,
  studentCsv,
  summaries,
  timeline,
  type TimelineEvent,
} from '../lib/analytics'
import { REFERENCE_DATE, SCHOOL_NAME, SCHOOL_YEAR } from '../lib/fixtures'

export const Route = createFileRoute('/students/$studentId')({
  loader: ({ params }) => {
    if (!getSummary(params.studentId)) throw notFound()
  },
  head: ({ params }) => ({
    meta: [{ title: `${getSummary(params.studentId)?.fullName ?? 'تلميذ'} — مِداد` }],
  }),
  component: Profile,
  notFoundComponent: () => (
    <div className="card mx-auto max-w-lg p-10 text-center">
      <p className="text-lg">لم يتم العثور على هذا التلميذ.</p>
      <Link to="/students" className="mt-4 inline-block text-teal underline">
        العودة إلى قائمة التلاميذ
      </Link>
    </div>
  ),
})

const tabs = ['سجل المتابعة', 'النقط', 'الحضور والغياب', 'الواجبات', 'السلوك والمشاركة'] as const

function Profile() {
  const { studentId } = Route.useParams()
  const s = getSummary(studentId)!
  const [tab, setTab] = useState<(typeof tabs)[number]>('سجل المتابعة')
  const classmates = summaries.filter((x) => x.group.id === s.group.id)
  const events = timeline(s.student)

  const gradeRows = s.student.grades.map((g) => {
    const a = getAssessment(g.assessmentId)
    const scores = classmates.map((c) => c.student.grades.find((x) => x.assessmentId === a.id)?.score ?? 0)
    return {
      label: a.title.replace('الفرض المحروس', 'الفرض'),
      title: a.title,
      date: a.date,
      score: g.score,
      classAverage: scores.reduce((x, y) => x + y, 0) / scores.length,
      rank: scores.filter((x) => x > g.score).length + 1,
    }
  })
  const rank = classmates.filter((c) => (c.average ?? 0) > (s.average ?? 0)).length + 1

  function download() {
    const url = URL.createObjectURL(new Blob([studentCsv(s)], { type: 'text/csv;charset=utf-8' }))
    const a = Object.assign(document.createElement('a'), {
      href: url,
      download: `ملف-${s.fullName.replace(/\s+/g, '-')}.csv`,
    })
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="mx-auto max-w-[80rem]">
      <Link
        to="/students"
        search={{ classId: s.group.id }}
        className="no-print rise mb-4 inline-flex items-center gap-1.5 text-sm text-ink-soft hover:text-teal"
      >
        <ArrowRight className="size-4" /> {s.group.name}
      </Link>

      <p className="mb-4 hidden text-sm text-ink-soft print:block">
        {SCHOOL_NAME} · الموسم الدراسي {SCHOOL_YEAR} · مادة اللغة العربية · بتاريخ {formatDate(REFERENCE_DATE)}
      </p>

      <PageHeader
        eyebrow={`الملف الشخصي · ${s.group.code} · رقم ${s.student.seat}`}
        title={s.fullName}
        actions={
          <>
            <button
              onClick={download}
              className="flex items-center gap-2 rounded-xl bg-teal-deep px-4 py-2.5 text-sm font-medium text-paper transition hover:bg-teal"
            >
              <Download className="size-4" /> تحميل الملف (CSV)
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-2 rounded-xl border border-line bg-card px-4 py-2.5 text-sm font-medium transition hover:border-teal/50"
            >
              <Printer className="size-4" /> طباعة / PDF
            </button>
          </>
        }
      >
        <span className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
          <span>
            رقم مسار: <span className="num font-medium text-ink">{s.student.massar}</span>
          </span>
          <span>
            تاريخ الازدياد: <span className="num">{s.student.birthDate}</span>
          </span>
          <span>
            هاتف الولي: <span className="num">{s.student.guardianPhone}</span>
          </span>
        </span>
      </PageHeader>

      {isStruggling(s) || s.reasons.length ? (
        <div
          className={`rise mb-6 flex flex-wrap items-center gap-3 rounded-2xl border p-4 ${
            isStruggling(s) ? 'border-bad/25 bg-bad-soft/70' : 'border-saffron/30 bg-saffron-soft'
          }`}
        >
          <TriangleAlert className={`size-5 ${isStruggling(s) ? 'text-bad' : 'text-[#7d5f10]'}`} />
          <p className="font-semibold">{isStruggling(s) ? 'تلميذ متعثر يحتاج إلى متابعة' : 'مؤشرات للانتباه'}</p>
          <div className="flex flex-wrap gap-1.5">
            {s.reasons.map((r) => (
              <Pill key={r.key} tone={isStruggling(s) ? 'bad' : 'warn'}>{r.label}</Pill>
            ))}
          </div>
        </div>
      ) : (
        <div className="rise mb-6 flex items-center gap-3 rounded-2xl border border-good/25 bg-good-soft/70 p-4 text-good">
          <ShieldCheck className="size-5" />
          <p className="font-semibold">لا توجد مؤشرات تعثر — مسار دراسي مستقر</p>
        </div>
      )}

      <section className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-5">
        <StatTile icon={GraduationCap} label="المعدل الحالي" tone="saffron" value={<ScoreBadge score={s.average} />} hint={`الرتبة ${rank} من ${classmates.length} في القسم`} />
        <StatTile icon={CalendarX2} label="الحضور" tone="good" value={<span className="num">{formatPercent(s.attendanceRate)}</span>} hint={`${s.absences} غيابات (${s.unjustified} غير مبررة) · ${s.lates} تأخرات`} />
        <StatTile icon={ClipboardList} label="الواجبات المنزلية" value={<span className="num">{s.homeworkDone}/{s.homeworkTotal}</span>} hint={s.homeworkMissing ? `${s.homeworkMissing} غير منجزة` : 'كلها منجزة أو متأخرة'} />
        <StatTile icon={Hand} label="المشاركة" tone="teal" value={<span className="num">{formatScore(s.participation)}</span>} hint="معدل التقدير الشهري من 10" />
        <StatTile icon={ShieldCheck} label="السلوك والانضباط" tone={s.negative ? 'bad' : 'good'} value={<span className="num">{s.positive ? `+${s.positive}` : '0'} / {s.negative ? `−${s.negative}` : '0'}</span>} hint="ملاحظات إيجابية / سلبية" />
      </section>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
        <section className="card min-w-0 p-5">
          <div role="tablist" aria-label="أقسام الملف" className="no-print mb-5 flex gap-1 overflow-x-auto border-b border-line">
            {tabs.map((t) => (
              <button
                key={t}
                role="tab"
                aria-selected={tab === t}
                onClick={() => setTab(t)}
                className={`-mb-px shrink-0 border-b-2 px-3.5 py-2.5 text-sm transition ${
                  tab === t ? 'border-clay font-semibold text-ink' : 'border-transparent text-ink-soft hover:text-ink'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          {tab === 'سجل المتابعة' ? <Timeline events={events} /> : null}

          {tab === 'النقط' ? (
            <table className="w-full text-sm">
              <thead className="text-xs text-ink-soft">
                <tr className="border-b border-line">
                  <th className="py-2 text-start font-medium">التقويم</th>
                  <th className="py-2 text-start font-medium">التاريخ</th>
                  <th className="py-2 font-medium">النقطة</th>
                  <th className="py-2 font-medium">معدل القسم</th>
                  <th className="py-2 font-medium">الرتبة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line/70">
                {gradeRows.map((g) => (
                  <tr key={g.title}>
                    <td className="py-3">{g.title}</td>
                    <td className="py-3 text-ink-soft">{formatDate(g.date)}</td>
                    <td className="py-3 text-center"><ScoreBadge score={g.score} /></td>
                    <td className="num py-3 text-center text-ink-soft">{formatScore(g.classAverage)}</td>
                    <td className="num py-3 text-center text-ink-soft">{g.rank}/{classmates.length}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : null}

          {tab === 'الحضور والغياب' ? (
            s.student.attendance.length ? (
              <ul className="divide-y divide-line/70">
                {s.student.attendance.map((a) => (
                  <li key={a.date + a.status} className="flex items-center justify-between py-3 text-sm">
                    <span>{formatDate(a.date, true)}</span>
                    <span className="flex gap-1.5">
                      <Pill tone={a.status === 'غائب' ? 'bad' : 'warn'}>{a.status}</Pill>
                      {a.status === 'غائب' ? (
                        <Pill tone={a.justified ? 'good' : 'neutral'}>{a.justified ? 'مبرر' : 'غير مبرر'}</Pill>
                      ) : null}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <Empty text={`حضور كامل في جميع الحصص (${s.sessions} حصة).`} />
            )
          ) : null}

          {tab === 'الواجبات' ? (
            <ul className="divide-y divide-line/70">
              {s.student.homework.map((h) => {
                const hw = getHomework(h.homeworkId)
                const pending = hw.due > REFERENCE_DATE
                return (
                  <li key={h.homeworkId} className="flex items-center justify-between gap-3 py-3 text-sm">
                    <span>
                      <span className="block">{hw.title}</span>
                      <span className="text-xs text-ink-faint">آخر أجل: {formatDate(hw.due)}</span>
                    </span>
                    {pending ? (
                      <Pill>لم يحن الأجل</Pill>
                    ) : (
                      <Pill tone={h.status === 'منجز' ? 'good' : h.status === 'متأخر' ? 'warn' : 'bad'}>{h.status}</Pill>
                    )}
                  </li>
                )
              })}
            </ul>
          ) : null}

          {tab === 'السلوك والمشاركة' ? (
            <div className="space-y-6">
              <div>
                <h3 className="mb-3 text-base">تقدير المشاركة الشهري</h3>
                <div className="grid grid-cols-3 gap-3">
                  {s.student.participation.map((p) => (
                    <div key={p.month} className="rounded-xl bg-paper/70 p-3 text-center">
                      <p className="text-xs text-ink-faint">{formatMonth(p.month)}</p>
                      <p className="num mt-1 font-display text-2xl">{p.score}<span className="text-sm text-ink-faint">/10</span></p>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="mb-3 text-base">ملاحظات السلوك والانضباط</h3>
                {s.student.behavior.length ? (
                  <ul className="space-y-2">
                    {s.student.behavior.map((b, i) => (
                      <li key={i} className="flex items-start justify-between gap-3 rounded-xl bg-paper/70 p-3 text-sm">
                        <span>{b.note}</span>
                        <span className="flex shrink-0 items-center gap-2">
                          <span className="text-xs text-ink-faint">{formatDate(b.date)}</span>
                          <Pill tone={b.kind === 'إيجابي' ? 'good' : 'bad'}>{b.kind}</Pill>
                        </span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <Empty text="لا توجد ملاحظات سلوكية مسجلة." />
                )}
              </div>
            </div>
          ) : null}
        </section>

        <aside className="space-y-6">
          <section className="card p-5">
            <SectionTitle>تطور النقط</SectionTitle>
            <StudentGradesChart rows={gradeRows} />
          </section>
          <section className="card p-5 text-sm leading-7 text-ink-soft">
            <SectionTitle>ملخص للمجلس</SectionTitle>
            <p>
              {s.student.gender === 'أ' ? 'التلميذة' : 'التلميذ'} {s.fullName} بقسم {s.group.code}، {s.student.gender === 'أ' ? 'معدلها' : 'معدله'} الحالي{' '}
              <b className="num text-ink">{formatScore(s.average)}</b> (الرتبة {rank})،{' '}
              {s.trend === null ? '' : s.trend >= 0.5 ? 'مع تحسن بين التقويمين، ' : s.trend <= -0.5 ? 'مع تراجع بين التقويمين، ' : 'مع استقرار في النتائج، '}
              ونسبة حضور <b className="num text-ink">{formatPercent(s.attendanceRate)}</b>.{' '}
              {isStruggling(s) ? `يُقترح ${s.student.gender === 'أ' ? 'إدراجها' : 'إدراجه'} في حصص الدعم والتواصل مع الولي.` : 'لا يستدعي الوضع تدخلاً خاصاً.'}
            </p>
          </section>
        </aside>
      </div>
    </div>
  )
}

const kindTone: Record<TimelineEvent['tone'], string> = {
  good: 'bg-good',
  bad: 'bg-bad',
  neutral: 'bg-saffron',
}

function Timeline({ events }: { events: TimelineEvent[] }) {
  if (!events.length) return <Empty text="لا توجد أحداث مسجلة بعد." />
  return (
    <ol className="relative space-y-1 ps-5 before:absolute before:inset-y-2 before:start-[5px] before:w-px before:bg-line">
      {events.map((e, i) => (
        <li key={i} className="relative flex items-start justify-between gap-3 rounded-lg py-2.5 pe-1">
          <span className={`absolute -start-5 top-4 size-[11px] rounded-full ring-4 ring-card ${kindTone[e.tone]}`} />
          <div>
            <p className="text-sm text-ink">{e.title}</p>
            <p className="text-xs text-ink-faint">
              {e.kind} · {formatDate(e.date, true)}
            </p>
          </div>
          <Pill tone={e.tone === 'good' ? 'good' : e.tone === 'bad' ? 'bad' : 'warn'}>
            <span className={e.kind === 'نقطة' ? 'num' : ''}>{e.detail}</span>
          </Pill>
        </li>
      ))}
    </ol>
  )
}

function Empty({ text }: { text: string }) {
  return <p className="rounded-xl bg-paper/70 p-6 text-center text-sm text-ink-faint">{text}</p>
}
