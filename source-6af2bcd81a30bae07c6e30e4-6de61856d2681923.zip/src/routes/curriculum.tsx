import { createFileRoute } from '@tanstack/react-router'
import { Check, Clock3 } from 'lucide-react'
import { useState } from 'react'
import { PageHeader, Pill, Progress } from '../components/ui'
import { formatDate, lessonProgress } from '../lib/analytics'
import { classes, REFERENCE_DATE } from '../lib/fixtures'
import { useStore } from '../lib/store'
import type { Lesson } from '../lib/types'

export const Route = createFileRoute('/curriculum')({ component: Curriculum })

const componentTone: Record<Lesson['component'], 'teal' | 'warn' | 'good' | 'neutral'> = {
  نصوص: 'teal',
  'علوم اللغة': 'warn',
  'تعبير وإنشاء': 'good',
  تقويم: 'neutral',
}

function Curriculum() {
  const { lessons, toggleLesson } = useStore()
  const [classId, setClassId] = useState(classes[0].id)
  const group = classes.find((c) => c.id === classId)!
  const own = lessons.filter((l) => l.classId === classId)
  const units = [...new Set(own.map((l) => l.unit))]

  return (
    <div className="mx-auto max-w-[80rem]">
      <PageHeader eyebrow="التوزيع السنوي للدروس" title="تقدم الدروس">
        قارن ما أنجزته في كل قسم بما هو مبرمج حتى اليوم. الخط الداكن على شريط التقدم يمثل المستوى المتوقع حسب التوزيع، واضغط على أي درس لتحديده كمنجز.
      </PageHeader>

      <section className="mb-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        {classes.map((c, i) => {
          const p = lessonProgress(c.id, lessons)
          const active = c.id === classId
          return (
            <button
              key={c.id}
              onClick={() => setClassId(c.id)}
              aria-pressed={active}
              className={`card rise p-4 text-start transition ${active ? 'ring-2 ring-teal' : 'hover:-translate-y-0.5'}`}
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="mb-2 flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 font-display">
                  <span className="size-2.5 rounded-full" style={{ background: c.color }} /> {c.code}
                </span>
                {p.behind ? (
                  <Pill tone="bad">متأخر −{p.behind}</Pill>
                ) : p.ahead ? (
                  <Pill tone="good">متقدم +{p.ahead}</Pill>
                ) : (
                  <Pill tone="teal">في الموعد</Pill>
                )}
              </div>
              <Progress label={`تقدم ${c.code}`} value={p.percent} marker={p.expected / p.total} color={c.color} />
              <p className="mt-2 text-xs text-ink-faint">
                <span className="num">{p.done}</span> منجز · <span className="num">{p.expected}</span> مبرمج حتى الآن ·{' '}
                <span className="num">{p.total}</span> إجمالاً
              </p>
            </button>
          )
        })}
      </section>

      <h2 className="mb-4 text-xl">{group.name}</h2>
      <div className="space-y-6">
        {units.map((unit) => (
          <section key={unit} className="card rise overflow-hidden">
            <h3 className="border-b border-line bg-paper-2/50 px-5 py-3 text-base">{unit}</h3>
            <ol className="divide-y divide-line/70">
              {own
                .filter((l) => l.unit === unit)
                .map((l) => {
                  const late = !l.doneDate && l.plannedDate <= REFERENCE_DATE
                  return (
                    <li key={l.id}>
                      <button
                        onClick={() => toggleLesson(l.id)}
                        className={`flex w-full items-center gap-4 px-5 py-3 text-start transition hover:bg-paper/70 ${late ? 'bg-bad-soft/30' : ''}`}
                      >
                        <span
                          className={`grid size-7 shrink-0 place-items-center rounded-full border-2 text-xs ${
                            l.doneDate ? 'border-good bg-good text-white' : late ? 'border-bad/60 text-bad' : 'border-line text-ink-faint'
                          }`}
                        >
                          {l.doneDate ? <Check className="size-4" strokeWidth={3} /> : <span className="num">{l.order}</span>}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className={`block ${l.doneDate ? 'text-ink-soft' : 'text-ink'}`}>{l.title}</span>
                          <span className="text-xs text-ink-faint">
                            مبرمج: {formatDate(l.plannedDate)}
                            {l.doneDate ? ` · أُنجز: ${formatDate(l.doneDate)}` : ''}
                          </span>
                        </span>
                        <Pill tone={componentTone[l.component]}>{l.component}</Pill>
                        {late ? (
                          <span className="flex items-center gap-1 text-xs font-semibold text-bad">
                            <Clock3 className="size-3.5" /> متأخر
                          </span>
                        ) : null}
                      </button>
                    </li>
                  )
                })}
            </ol>
          </section>
        ))}
      </div>
    </div>
  )
}
