import { createFileRoute, Link } from '@tanstack/react-router'
import {
  AlarmClock,
  ArrowLeft,
  BellRing,
  BookMarked,
  CalendarCheck,
  ClipboardCheck,
  GraduationCap,
  TriangleAlert,
  UsersRound,
} from 'lucide-react'
import { AttendanceChart, ClassAveragesChart, DistributionChart } from '../components/charts'
import { Avatar, PageHeader, Pill, Progress, ScoreBadge, SectionTitle, StatTile } from '../components/ui'
import {
  allClassStats,
  daysBetween,
  dueLabel,
  formatDate,
  formatLongDate,
  formatPercent,
  formatScore,
  getClass,
  gradeDistribution,
  isStruggling,
  lessonProgress,
  summaries,
  taskState,
  weeklyAttendance,
} from '../lib/analytics'
import { classes, REFERENCE_DATE, TEACHER_NAME } from '../lib/fixtures'
import { useStore } from '../lib/store'

export const Route = createFileRoute('/')({ component: Home })

const struggling = summaries
  .filter(isStruggling)
  .sort((a, b) => b.reasons.length - a.reasons.length || (a.average ?? 0) - (b.average ?? 0))
const overallAverage = summaries.reduce((a, s) => a + (s.average ?? 0), 0) / summaries.length
const attendance = summaries.reduce((a, s) => a + s.attendanceRate, 0) / summaries.length
const homeworkRate =
  summaries.reduce((a, s) => a + s.homeworkDone, 0) /
  summaries.reduce((a, s) => a + s.homeworkTotal, 0)
const passRate = summaries.filter((s) => (s.average ?? 0) >= 10).length / summaries.length
const attendanceRows = weeklyAttendance(classes.map((c) => c.id)).map((w) => ({
  label: formatDate(w.week),
  rate: w.rate,
}))
const schoolWeek = Math.floor(daysBetween('2026-09-14', REFERENCE_DATE) / 7) + 1

function Home() {
  const { tasks, lessons } = useStore()
  const overdue = tasks
    .filter((t) => taskState(t).state === 'متأخرة')
    .sort((a, b) => a.due.localeCompare(b.due))
  const upcoming = tasks
    .filter((t) => ['اليوم', 'هذا الأسبوع'].includes(taskState(t).state))
    .sort((a, b) => a.due.localeCompare(b.due))
  const progress = classes.map((c) => ({ group: c, ...lessonProgress(c.id, lessons) }))
  const behindClasses = progress.filter((p) => p.behind > 0)
  const totalDone = progress.reduce((a, p) => a + p.done, 0)
  const totalLessons = progress.reduce((a, p) => a + p.total, 0)

  return (
    <div className="mx-auto max-w-[88rem]">
      <PageHeader
        eyebrow={`${formatLongDate(REFERENCE_DATE)} · الدورة الأولى · الأسبوع ${schoolWeek}`}
        title={`صباح الخير، ${TEACHER_NAME}`}
      >
        هذه صورة شاملة عن أقسامك الخمسة: النتائج، الحضور، تقدم الدروس، والمهام التي تنتظرك.
      </PageHeader>

      {/* شريط التنبيهات */}
      <section
        aria-label="تنبيهات"
        className="rise mb-6 grid gap-3 md:grid-cols-3"
        style={{ animationDelay: '60ms' }}
      >
        <AlertLink
          to="/tasks"
          tone="bad"
          icon={AlarmClock}
          title={overdue.length ? `${overdue.length} مهام متأخرة` : 'لا توجد مهام متأخرة'}
          text={overdue[0] ? `أقدمها: ${overdue[0].title}` : 'كل المهام في موعدها'}
        />
        <AlertLink
          to="/students"
          search={{ filter: 'struggling' }}
          tone="clay"
          icon={TriangleAlert}
          title={`${struggling.length} تلميذاً متعثراً`}
          text="معدل دون 10 أو مؤشرات متعددة: غياب، واجبات، سلوك"
        />
        <AlertLink
          to="/curriculum"
          tone="saffron"
          icon={BookMarked}
          title={
            behindClasses.length
              ? `${behindClasses.length} أقسام متأخرة في التوزيع`
              : 'التوزيع السنوي في موعده'
          }
          text={
            behindClasses.length
              ? behindClasses.map((p) => `${p.group.code} (−${p.behind})`).join('، ')
              : 'جميع الأقسام وفق البرمجة'
          }
        />
      </section>

      {/* المؤشرات */}
      <section aria-label="المؤشرات الرئيسية" className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <StatTile delay={80} icon={UsersRound} label="إجمالي التلاميذ" value={<span className="num">{summaries.length}</span>} hint={`${classes.length} أقسام · من 33 إلى 38 تلميذاً`} />
        <StatTile delay={120} icon={GraduationCap} label="المعدل العام" value={<span className="num">{formatScore(overallAverage)}</span>} hint={`نسبة المتوسط فما فوق ${formatPercent(passRate)}`} tone="saffron" />
        <StatTile delay={160} icon={CalendarCheck} label="نسبة الحضور" value={<span className="num">{formatPercent(attendance)}</span>} hint="منذ بداية الدراسة" tone="good" />
        <StatTile delay={200} icon={TriangleAlert} label="المتعثرون" value={<span className="num">{struggling.length}</span>} hint={`${formatPercent(struggling.length / summaries.length)} من مجموع التلاميذ`} tone="clay" />
        <StatTile delay={240} icon={ClipboardCheck} label="إنجاز الواجبات" value={<span className="num">{formatPercent(homeworkRate)}</span>} hint="الواجبات المنزلية المستحقة" />
        <StatTile delay={280} icon={BookMarked} label="تقدم التوزيع السنوي" value={<span className="num">{formatPercent(totalDone / totalLessons)}</span>} hint={`${totalDone} درساً منجزاً من ${totalLessons}`} tone="teal" />
      </section>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_24rem]">
        <div className="min-w-0 space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <section className="card rise p-5" style={{ animationDelay: '200ms' }}>
              <SectionTitle aside={<span className="text-xs text-ink-faint">من 20</span>}>معدلات الأقسام</SectionTitle>
              <ClassAveragesChart
                rows={allClassStats.map((s) => ({ label: s.group.code, value: s.average, color: s.group.color }))}
              />
            </section>
            <section className="card rise p-5" style={{ animationDelay: '260ms' }}>
              <SectionTitle aside={<Pill tone="warn">دون 10 بلون مميز</Pill>}>توزيع معدلات التلاميذ</SectionTitle>
              <DistributionChart rows={gradeDistribution(summaries)} />
            </section>
          </div>

          <section className="card rise p-5" style={{ animationDelay: '320ms' }}>
            <SectionTitle aside={<span className="text-xs text-ink-faint">جميع الأقسام · أسبوعياً</span>}>
              تطور نسبة الحضور
            </SectionTitle>
            <AttendanceChart rows={attendanceRows} />
          </section>

          {/* بطاقات الأقسام */}
          <section aria-label="الأقسام">
            <SectionTitle>الأقسام</SectionTitle>
            <div className="grid gap-4 sm:grid-cols-2 2xl:grid-cols-3">
              {allClassStats.map((s, i) => {
                const p = progress[i]
                return (
                  <Link
                    key={s.group.id}
                    to="/students"
                    search={{ classId: s.group.id }}
                    className="card rise group block overflow-hidden transition hover:-translate-y-0.5 hover:border-teal/40"
                    style={{ animationDelay: `${360 + i * 50}ms` }}
                  >
                    <div className="h-1.5" style={{ background: s.group.color }} />
                    <div className="p-5">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="text-lg text-ink">{s.group.code}</h3>
                          <p className="text-xs text-ink-faint">{s.group.name}</p>
                        </div>
                        {s.struggling ? <Pill tone="bad">{s.struggling} متعثرين</Pill> : null}
                      </div>
                      <dl className="mt-4 grid grid-cols-3 gap-2 text-center">
                        <Metric label="المعدل" value={formatScore(s.average)} />
                        <Metric label="الحضور" value={formatPercent(s.attendanceRate)} />
                        <Metric label="الواجبات" value={formatPercent(s.homeworkRate)} />
                      </dl>
                      <div className="mt-4">
                        <div className="mb-1.5 flex justify-between text-xs text-ink-soft">
                          <span>التوزيع السنوي</span>
                          <span className="num">
                            {p.done} / {p.total}
                          </span>
                        </div>
                        <Progress
                          label={`تقدم دروس ${s.group.code}`}
                          value={p.percent}
                          marker={p.expected / p.total}
                          color={s.group.color}
                        />
                        <p className="mt-2 text-xs text-ink-faint">
                          {p.behind ? (
                            <span className="text-bad">متأخر بـ {p.behind} {p.behind === 1 ? 'درس' : 'دروس'} · </span>
                          ) : null}
                          التالي: {p.next?.title ?? '—'}
                        </p>
                      </div>
                    </div>
                  </Link>
                )
              })}
            </div>
          </section>
        </div>

        {/* العمود الجانبي */}
        <aside className="space-y-6">
          <section className="card rise p-5" style={{ animationDelay: '240ms' }}>
            <SectionTitle
              aside={
                <Link to="/tasks" className="flex items-center gap-1 text-xs font-medium text-teal hover:underline">
                  كل المهام <ArrowLeft className="size-3.5" />
                </Link>
              }
            >
              المهام
            </SectionTitle>
            {overdue.length ? (
              <div className="mb-4 rounded-xl border border-bad/20 bg-bad-soft/60 p-3">
                <p className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-bad">
                  <BellRing className="size-4" /> متأخرة
                </p>
                <ul className="space-y-2">
                  {overdue.map((t) => (
                    <TaskLine key={t.id} title={t.title} meta={dueLabel(t)} classId={t.classId} bad />
                  ))}
                </ul>
              </div>
            ) : null}
            <p className="mb-2 text-sm font-semibold text-ink-soft">هذا الأسبوع</p>
            <ul className="space-y-2">
              {upcoming.slice(0, 6).map((t) => (
                <TaskLine key={t.id} title={t.title} meta={`${formatDate(t.due, true)} · ${dueLabel(t)}`} classId={t.classId} />
              ))}
              {!upcoming.length ? <li className="text-sm text-ink-faint">لا مهام هذا الأسبوع.</li> : null}
            </ul>
          </section>

          <section className="card rise p-5" style={{ animationDelay: '300ms' }}>
            <SectionTitle
              aside={
                <Link
                  to="/students"
                  search={{ filter: 'struggling' }}
                  className="flex items-center gap-1 text-xs font-medium text-teal hover:underline"
                >
                  القائمة الكاملة <ArrowLeft className="size-3.5" />
                </Link>
              }
            >
              تنبيه المتعثرين
            </SectionTitle>
            <ul className="divide-y divide-line">
              {struggling.slice(0, 7).map((s) => (
                <li key={s.student.id}>
                  <Link
                    to="/students/$studentId"
                    params={{ studentId: s.student.id }}
                    className="flex items-center gap-3 py-2.5 transition hover:bg-paper/60"
                  >
                    <Avatar name={s.student.firstName} color={s.group.color} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{s.fullName}</p>
                      <p className="truncate text-xs text-ink-faint">
                        {s.group.code} · {s.reasons.map((r) => r.label).join('، ')}
                      </p>
                    </div>
                    <ScoreBadge score={s.average} />
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        </aside>
      </div>
    </div>
  )
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-paper/70 py-2">
      <dt className="text-[0.7rem] text-ink-faint">{label}</dt>
      <dd className="num mt-0.5 text-sm font-semibold text-ink">{value}</dd>
    </div>
  )
}

function TaskLine({
  title,
  meta,
  classId,
  bad,
}: {
  title: string
  meta: string
  classId: string | null
  bad?: boolean
}) {
  const group = classId ? getClass(classId) : null
  return (
    <li className="flex gap-2.5">
      <span
        className="mt-1.5 size-2 shrink-0 rounded-full"
        style={{ background: group?.color ?? '#8a918c' }}
        aria-hidden
      />
      <div className="min-w-0">
        <p className="text-sm leading-6 text-ink">{title}</p>
        <p className={`text-xs ${bad ? 'text-bad' : 'text-ink-faint'}`}>
          {group ? `${group.code} · ` : ''}
          {meta}
        </p>
      </div>
    </li>
  )
}

function AlertLink({
  to,
  search,
  tone,
  icon: Icon,
  title,
  text,
}: {
  to: '/tasks' | '/students' | '/curriculum'
  search?: { filter: 'struggling' }
  tone: 'bad' | 'clay' | 'saffron'
  icon: typeof AlarmClock
  title: string
  text: string
}) {
  const tones = {
    bad: 'border-bad/25 bg-bad-soft/70 text-bad',
    clay: 'border-clay/25 bg-clay-soft/70 text-clay',
    saffron: 'border-saffron/30 bg-saffron-soft text-[#7d5f10]',
  }
  return (
    <Link
      to={to}
      search={search as never}
      className={`group flex items-center gap-3 rounded-2xl border p-4 transition hover:-translate-y-0.5 ${tones[tone]}`}
    >
      <Icon className="size-6 shrink-0" strokeWidth={1.8} />
      <div className="min-w-0 flex-1">
        <p className="font-semibold">{title}</p>
        <p className="truncate text-xs opacity-80">{text}</p>
      </div>
      <ArrowLeft className="size-4 shrink-0 transition group-hover:-translate-x-1" />
    </Link>
  )
}
